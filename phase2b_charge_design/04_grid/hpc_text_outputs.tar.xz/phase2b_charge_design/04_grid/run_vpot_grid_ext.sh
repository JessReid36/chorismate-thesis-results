#!/bin/bash
# Compute V_R, V_TS at the extended grid points via orca_vpot, using committed 02_singlepoints wavefunctions.
# Convention (TIER2_KNOWN_ISSUES E3): arg1=.gbw arg2=.scfp member(relative) arg3=points(Bohr) arg4=out arg5=.densities container(full path)
# Run on HPC from 04_grid (where grid_ext_points.tsv lives).
set -e
SP=~/system_development/phase2b_charge_design/02_singlepoints
VPOT=/home/apps2/ORCA/6.0.1/orca_vpot
# 1. points -> Bohr
python3 - <<'PY'
A2B=1.8897259886
rows=open("grid_ext_points.tsv").read().splitlines()[1:]
open("grid_ext_bohr.xyz","w").write("%d\n"%len(rows)+"\n".join(
  "%.8f %.8f %.8f"%(float(p[1])*A2B,float(p[2])*A2B,float(p[3])*A2B) for p in (r.split("\t") for r in rows))+"\n")
print("wrote grid_ext_bohr.xyz (%d pts)"%len(rows))
PY
# 2. vpot for R and TS
$VPOT $SP/sp_reactant.gbw sp_reactant.scfp grid_ext_bohr.xyz vpot_R_ext.out $SP/sp_reactant
$VPOT $SP/sp_ts.gbw       sp_ts.scfp       grid_ext_bohr.xyz vpot_TS_ext.out $SP/sp_ts
# 3. assemble dv_grid_ext.tsv (idx x y z shell V_R V_TS Dv)  - matches the format the optimiser reads
python3 - <<'PY'
def rd(f):
    v=[]
    for ln in open(f):
        t=ln.split()
        if len(t)>=4:
            try: v.append(float(t[3]))
            except: pass
    return v
VR=rd("vpot_R_ext.out"); VT=rd("vpot_TS_ext.out")
rows=open("grid_ext_points.tsv").read().splitlines()[1:]
assert len(VR)==len(VT)==len(rows),"mismatch %d/%d/%d"%(len(VR),len(VT),len(rows))
out=["idx\tx_ang\ty_ang\tz_ang\tshell\tV_R\tV_TS\tDv"]
for ln,vr,vt in zip(rows,VR,VT):
    p=ln.split("\t"); out.append("%s\t%s\t%s\t%s\t%s\t%.8f\t%.8f\t%.8f"%(p[0],p[1],p[2],p[3],p[4],vr,vt,vt-vr))
open("dv_grid_ext.tsv","w").write("\n".join(out)+"\n")
print("wrote dv_grid_ext.tsv (%d points, all shells 2-8A, with Dv)"%len(rows))
PY
echo "DONE. Verify: the 2/3/4A Dv should be close (not identical - re-thinned grid) to the original dv_grid.tsv."
