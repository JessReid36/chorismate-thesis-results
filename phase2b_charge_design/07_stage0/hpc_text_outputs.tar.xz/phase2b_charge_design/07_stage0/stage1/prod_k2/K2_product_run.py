import sys, openmm
from ash import Fragment, ORCATheory, OpenMMTheory, QMMMTheory, Optimizer

RUN = (len(sys.argv) > 1 and sys.argv[1] == "run")
ORCADIR = "/home/apps2/ORCA/6.0.1"

# 38 atoms: 0-23 QM substrate (dianion, -2); 24-33 MM guanidinium(+1); 34-37 MM formate(-1).
# QM stays -2 (MM adds field, not electrons -> no polyanion problem). MM carries partial charges
# (sum +1/-1) AND explicit Lennard-Jones vs every QM atom (directional H-bond well + Pauli wall).
coords = """C  60.092356 34.056984 56.354594
H  60.757862 33.544930 57.062775
H  60.607676 34.925793 55.921397
C  58.844721 34.465867 57.095841
C  58.158936 35.830179 56.839235
O  58.893519 36.799815 56.528907
O  56.917200 35.847731 56.992850
O  58.307613 33.702214 57.875302
C  57.548698 31.938147 55.699735
H  56.940391 31.183730 56.203549
C  58.878432 31.920015 55.800043
H  59.399305 31.165241 56.389488
C  59.744487 33.008977 55.219846
C  59.028550 33.707589 54.087981
H  59.670812 34.192743 53.346365
C  57.695381 33.716804 53.971810
H  57.195032 34.246401 53.154887
C  56.810468 33.035130 54.981426
H  56.513401 33.810335 55.714955
O  55.640479 32.543634 54.338392
H  55.032504 32.220885 55.020192
C  61.077105 32.332661 54.739361
O  61.765259 31.766738 55.625475
O  61.336808 32.358221 53.517478
C  63.004400 29.116300 52.225600
O  64.182604 29.207656 51.818181
O  62.315539 28.073627 52.253927
H  62.530138 30.038301 52.593009
C  57.499400 32.313000 60.999500
N  57.649977 32.698220 59.735446
H  57.339460 33.360722 60.431700
H  57.846146 31.743182 59.999113
N  57.090501 33.185404 61.916349
H  57.286670 32.230366 62.180016
H  57.204849 33.477940 60.956428
N  57.757721 31.055376 61.346705
H  57.872070 31.347911 60.386784
H  57.447204 31.717878 62.042959"""

frag = Fragment(coordsstring=coords, charge=-2, mult=1)
print(">> Fragment: %d atoms (24 QM + 14 MM surrogate)" % frag.numatoms)

qmatoms = list(range(24))
# MM partial charges (guanidinium net +1, formate net -1); QM atoms carry 0 in the MM charge list
mmcharges = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.45, -0.8, -0.8, 0.15, 0.64, -0.8, 0.46, 0.46, -0.8, 0.46, 0.46, -0.8, 0.46, 0.46]  # K2 product
print(">> MM charge sum = %+.2f (net 0 for K2); QM subsystem stays -2" % sum(mmcharges))

# per-element LJ (sigma A, eps kcal/mol), OPLS-ish
LJ = {"C":(3.40,0.086),"N":(3.25,0.170),"O":(2.96,0.210),"H":(1.06,0.016)}
els = ['C', 'H', 'H', 'C', 'C', 'O', 'O', 'O', 'C', 'H', 'C', 'H', 'C', 'C', 'H', 'C', 'H', 'C', 'H', 'O', 'H', 'C', 'O', 'O', 'C', 'O', 'O', 'H', 'C', 'N', 'H', 'H', 'N', 'H', 'H', 'N', 'H', 'H']

orca = ORCATheory(orcadir=ORCADIR,
                  orcasimpleinput="! B3LYP D3BJ def2-SVP def2/J RIJCOSX CPCM TightSCF",
                  orcablocks="%cpcm epsilon 4.0 end\n%scf MaxIter 300 Guess PModel end",
                  numcores=8, autostart=False)
print(">> ORCATheory built")

mm = OpenMMTheory(fragment=frag, dummysystem=True, platform="CPU", numcores=1,
                  autoconstraints=None, rigidwater=False)
print(">> OpenMMTheory built")

# explicit QM-substrate <-> MM-surrogate Lennard-Jones via CustomBondForce (LB combining)
# E = 4*eps*((sig/r)^12 - (sig/r)^6)  -> wall + directional well
lj = openmm.CustomBondForce("4*eps*((sig/r)^12 - (sig/r)^6)")
lj.addPerBondParameter("sig"); lj.addPerBondParameter("eps")
lj.setUsesPeriodicBoundaryConditions(False)
ang = openmm.unit.angstrom; kcal = openmm.unit.kilocalorie_per_mole
npair=0
for i in range(24):
    si,ei = LJ[els[i]]
    for j in range(24,24+14):
        sj,ej = LJ[els[j]]
        sig = ((si+sj)/2*ang).value_in_unit(openmm.unit.nanometer)
        eps = (((ei*ej)**0.5)*kcal).value_in_unit(openmm.unit.kilojoule_per_mole)
        lj.addBond(i, j, [sig, eps]); npair+=1
lj.setForceGroup(11)
mm.system.addForce(lj)
print(">> explicit QM-MM LJ added: %d pairs (directional well + Pauli wall)" % npair)

qmmm = QMMMTheory(qm_theory=orca, mm_theory=mm, fragment=frag,
                  qmatoms=qmatoms, charges=mmcharges, embedding="elstat",
                  qm_charge=-2, qm_mult=1, numcores=8)
print(">> QMMMTheory built | QM -2 | MM molecular surrogates with charges+LJ")

FROZEN = list(range(24,24+14))  # surrogates fixed at certified positions

if not RUN:
    print("\n=== DRY RUN OK (K2 PRODUCT) — %d LJ pairs, QM -2, %d frozen MM. ===" % (npair,len(FROZEN)))
    sys.exit(0)

# reaction-relevant loose convergence: substrate is floppy in the field; default GAU (gmax 4.5e-4)
# is unreachable. Runs plateau ~gmax 5-9e-3 -> set gmax 6e-3, grms 3e-3 so it CONVERGES on the real minimum.
LOOSE = {"convergence_energy": 1e-5, "convergence_grms": 3.0e-3, "convergence_gmax": 6.0e-3,
         "convergence_drms": 1.0e-2, "convergence_dmax": 1.5e-2}
Optimizer(theory=qmmm, fragment=frag, coordsystem="hdlc",
          frozenatoms=FROZEN, maxiter=300, charge=-2, mult=1, conv_criteria=LOOSE)
frag.write_xyzfile("k2_product_relaxed.xyz")
print(">> DONE -> k2_mmsurr_relaxed.xyz")
