# GATE CHECK (from research): is the injected CustomBondForce LJ wall actually evaluated,
# or silently ignored because the OpenMM Context wasn't reinitialized after adding it?
# Method: build the K2 QM/MM exactly as in production, then compute the MM-layer energy
# WITH and WITHOUT the LJ force. If they differ, the wall is live. If identical, it's dead.
import sys, openmm
from ash import Fragment, ORCATheory, OpenMMTheory, QMMMTheory

ORCADIR="/home/apps2/ORCA/6.0.1"
coords=open("mmsurr/k2_mmsurr_loose_final.xyz").read()
frag=Fragment(coordsstring="\n".join(coords.split("\n")[2:2+38]), charge=-2, mult=1)
qmatoms=list(range(24))
guan_q=[0.64]+[-0.80,0.46,0.46]*3; form_q=[0.45,-0.80,-0.80,0.15]
mmcharges=[0.0]*24+guan_q+form_q
LJ={"C":(3.40,0.086),"N":(3.25,0.170),"O":(2.96,0.210),"H":(1.06,0.016)}
els=[a.split()[0] for a in coords.split("\n")[2:2+38]]

mm=OpenMMTheory(fragment=frag, dummysystem=True, platform="CPU", numcores=1,
                autoconstraints=None, rigidwater=False)

# MM energy BEFORE adding the LJ force
import numpy as np
def mm_energy(theory, frag):
    r=theory.run(current_coords=frag.coords, elems=frag.elems, Grad=False)
    return r if np.isscalar(r) else r[0]
E_before = mm_energy(mm, frag)

# add the LJ CustomBondForce (as production does)
lj=openmm.CustomBondForce("4*eps*((sig/r)^12 - (sig/r)^6)")
lj.addPerBondParameter("sig"); lj.addPerBondParameter("eps"); lj.setUsesPeriodicBoundaryConditions(False)
ang=openmm.unit.angstrom; kcal=openmm.unit.kilocalorie_per_mole
for i in range(24):
    si,ei=LJ[els[i]]
    for j in range(24,38):
        sj,ej=LJ[els[j]]
        sig=((si+sj)/2*ang).value_in_unit(openmm.unit.nanometer)
        eps=(((ei*ej)**0.5)*kcal).value_in_unit(openmm.unit.kilojoule_per_mole)
        lj.addBond(i,j,[sig,eps])
lj.setForceGroup(11)
mm.system.addForce(lj)

# CRITICAL: does ASH's OpenMMTheory rebuild the Context/simulation so the new force is seen?
# Try WITHOUT reinit first (what production did), then WITH reinit.
E_after_noreinit = mm_energy(mm, frag)

# force a reinit the way the research prescribes
try:
    mm.simulation.context.reinitialize(preserveState=True)
    reinit_ok=True
except Exception as e:
    reinit_ok=False; print("reinit attempt error:", e)
E_after_reinit = mm_energy(mm, frag)

print("=== LJ GATE CHECK (K2 geometry) ===")
print("MM energy before LJ add      : %.6f" % E_before)
print("MM energy after add (no reinit): %.6f  (delta %.6e)" % (E_after_noreinit, E_after_noreinit-E_before))
print("MM energy after reinitialize : %.6f  (delta %.6e)" % (E_after_reinit, E_after_reinit-E_before))
print()
if abs(E_after_noreinit-E_before)>1e-9:
    print("VERDICT: LJ is LIVE without explicit reinit (ASH rebuilds context on run()). Production runs valid.")
elif reinit_ok and abs(E_after_reinit-E_before)>1e-9:
    print("VERDICT: LJ was DEAD until reinit! Production runs may have run WITHOUT the wall. MUST re-examine.")
else:
    print("VERDICT: LJ shows NO effect even after reinit - something else wrong, investigate.")
