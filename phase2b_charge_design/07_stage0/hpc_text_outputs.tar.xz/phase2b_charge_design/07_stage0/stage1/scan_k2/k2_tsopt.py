import sys, openmm
from ash import Fragment, ORCATheory, OpenMMTheory, QMMMTheory, Optimizer, NumFreq

RUN = (len(sys.argv) > 1 and sys.argv[1] == "run")
ORCADIR = "/home/apps2/ORCA/6.0.1"

# scan peak geometry (O3-C4 ~2.55) as the TS guess
ts = Fragment(xyzfile="k2_ts_guess.xyz", charge=-2, mult=1)
print(">> TS guess %d atoms" % ts.numatoms)

qmatoms=list(range(24))
guan_q=[0.64]+[-0.80,0.46,0.46]*3; form_q=[0.45,-0.80,-0.80,0.15]
mmcharges=[0.0]*24+guan_q+form_q
LJ={"C":(3.40,0.086),"N":(3.25,0.170),"O":(2.96,0.210),"H":(1.06,0.016)}
els=[l.split()[0] for l in open("k2_ts_guess.xyz").read().split("\n")[2:2+38]]

orca=ORCATheory(orcadir=ORCADIR,
                orcasimpleinput="! B3LYP D3BJ def2-SVP def2/J RIJCOSX CPCM TightSCF",
                orcablocks="%cpcm epsilon 4.0 end\n%scf MaxIter 300 Guess PModel end",
                numcores=8, autostart=False)
mm=OpenMMTheory(fragment=ts, dummysystem=True, platform="CPU", numcores=1,
               autoconstraints=None, rigidwater=False)
lj=openmm.CustomBondForce("4*eps*((sig/r)^12 - (sig/r)^6)")
lj.addPerBondParameter("sig"); lj.addPerBondParameter("eps"); lj.setUsesPeriodicBoundaryConditions(False)
ang=openmm.unit.angstrom; kcal=openmm.unit.kilocalorie_per_mole
for i in range(24):
    si,ei=LJ[els[i]]
    for j in range(24,38):
        sj,ej=LJ[els[j]]
        lj.addBond(i,j,[((si+sj)/2*ang).value_in_unit(openmm.unit.nanometer),
                        (((ei*ej)**0.5)*kcal).value_in_unit(openmm.unit.kilojoule_per_mole)])
lj.setForceGroup(11); mm.system.addForce(lj)
qmmm=QMMMTheory(qm_theory=orca, mm_theory=mm, fragment=ts, qmatoms=qmatoms,
                charges=mmcharges, embedding="elstat", qm_charge=-2, qm_mult=1, numcores=8)
print(">> QMMMTheory built | TSOpt")

# reacting atoms + neighbours for the partial Hessian (TS mode is O3-C4 break / C1-C6 form)
pH=[0,7,8,12, 3,4,10,13,17]

if not RUN:
    print("\n=== DRY RUN OK (K2 TSOpt from scan peak) ===")
    sys.exit(0)

# P-RFO TS optimisation, HDLC, active region = QM, partial Hessian on reacting atoms
Optimizer(theory=qmmm, fragment=ts, TSOpt=True, coordsystem='hdlc',
          ActiveRegion=True, actatoms=qmatoms,
          partial_hessian_atoms=pH,
          maxiter=200, charge=-2, mult=1,
          conv_criteria={"convergence_energy":1e-5,"convergence_grms":3.0e-3,
                         "convergence_gmax":6.0e-3,"convergence_drms":1.0e-2,"convergence_dmax":1.5e-2})
ts.write_xyzfile(xyzfilename="k2_ts_opt.xyz")
print(">> TS optimised -> k2_ts_opt.xyz")

# verify: partial Hessian frequency -> expect ONE imaginary mode along O3-C4/C1-C6
NumFreq(theory=qmmm, fragment=ts, hessatoms=qmatoms, npoint=2, charge=-2, mult=1)
print(">> NumFreq done - check for single imaginary frequency")
