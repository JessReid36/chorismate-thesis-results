#!/bin/bash
# CORRECTED barrier: use ORCA "QM energy" (substrate + embedding), NOT the QM/MM total (which carries a
# non-cancelling ~780 kcal/mol MM+LJ+interaction offset). barrier = (QMe_TS - QMe_react)*627.509.
echo "shell | QMe_react     QMe_TS       | barrier | vs+17.47 | verdict"
echo "------|---------------------------|---------|----------|--------"
for tag in 2p0 3p0 4p0 5p0 6p0 7p0 7p1 7p2 7p3 7p4 7p5 7p6 7p7 7p8 7p9 8p0 8p1 8p2 8p3 8p4 8p5 8p6 8p7 8p8 8p9 9p0 10p0 11p0 12p0 13p0 14p0 15p0; do
  rlog=run_shell$tag/ladder_${tag}_relax.log
  tslog=run_barr_$tag/barr_${tag}_relax.log
  [ -f "$tslog" ] || tslog=run_barr_$tag/barr8_ts_relax.log   # fallback for the first 8p0 job name
  [ -f "$rlog" ] && [ -f "$tslog" ] || { printf '%-5s | waiting\n' "$tag"; continue; }
  # last "QM energy" line from each (substrate electronic energy WITH embedding)
  er=$(grep -iE "^ *QM energy" "$rlog" | tail -1 | grep -oE '\-?[0-9]+\.[0-9]+')
  et=$(grep -iE "^ *QM energy" "$tslog" | tail -1 | grep -oE '\-?[0-9]+\.[0-9]+')
  # fragmented reactant flag
  rx=run_shell$tag/shell${tag}_relaxed.xyz
  frag=""
  [ -f "$rx" ] && frag=$(python3 -c "
import math
L=open('$rx').read().splitlines();a=[[float(v) for v in L[2+i].split()[1:4]] for i in range(24)]
print('FRAG' if math.sqrt(sum((a[7][k]-a[8][k])**2 for k in range(3)))>2.2 else '')
" 2>/dev/null)
  if [ -n "$er" ] && [ -n "$et" ]; then
    python3 -c "
er=float('$er'); et=float('$et'); b=(et-er)*627.509
frag='$frag'
verdict = frag+' (no valid barrier)' if frag else ('CATALYTIC ***' if b<17.47 else 'anti/non-cat')
print('%-5s | %12.6f %12.6f | %+7.2f | %+6.2f   | %s'%('$tag',er,et,b,b-17.47,verdict))
"
  else
    printf '%-5s | (QM energy line not found - check log)\n' "$tag"
  fi
done
