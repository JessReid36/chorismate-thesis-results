#!/bin/bash
# GOCAT gate: a design PASSES (eligible for NEB) iff BOTH endpoints: intact (O3-C4<2.2), RMSG<beta(10),
# and not destabilised. Bare refs (QM-only, from committed singlepoints): reactant ~ -836.x, product ~ -836.x
BETA=10.0
echo "design | R:O3C4 R:RMSG | P:O3C4 P:RMSG | GOCAT verdict"
echo "-------|---------------|---------------|-------------"
for tag in 2p0 7p0 7p1 7p2 7p3 7p4 7p5 7p6 7p7 7p8 7p9 8p0 8p1 8p2 8p3 8p5 8p6 8p7 8p8 8p9 9p0 10p0 11p0 12p0 13p0 15p0; do
  rf=run_screen_${tag}_reactant/shell${tag}_reactant_screen.txt
  pf=run_screen_${tag}_product/shell${tag}_product_screen.txt
  if [ ! -f "$rf" ] || [ ! -f "$pf" ]; then echo "$(printf '%-6s' $tag)| waiting"; continue; fi
  python3 -c "
def rd(f):
    d={}
    for ln in open(f): 
        k,v=ln.strip().split('='); d[k]=float(v)
    return d
r=rd('$rf'); p=rd('$pf'); beta=$BETA
rok = r['O3C4']<2.2 and r['RMSG']<beta
pok = p['O3C4']<2.2 and p['RMSG']<beta
verdict = 'PASS -> NEB' if (rok and pok) else 'FAIL (non-cat: '+ (', '.join([x for x,c in [('R-broken',r['O3C4']>=2.2),('R-notmin',r['RMSG']>=beta),('P-broken',p['O3C4']>=2.2),('P-notmin',p['RMSG']>=beta)] if c]))+')'
print('%-6s| %.3f  %6.2f | %.3f  %6.2f | %s'%('$tag',r['O3C4'],r['RMSG'],p['O3C4'],p['RMSG'],verdict))
"
done
