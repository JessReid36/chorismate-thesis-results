#!/bin/bash
# Stage 2: v2 NEB between FIELD-RELAXED reactant + product for all intact designs.
# Run AFTER stage 1 done. Needs shell<tag>_relaxed.xyz (reactant, from ladder) + shell<tag>_prod_relaxed.xyz
# (from stage 1) + shell<tag>_charges.txt. Run from 05d_shell_ladder/relax.
set -e
INTACT="2p0 7p0 7p1 7p2 7p3 7p4 7p5 7p6 7p7 7p8 7p9 8p0 8p1 8p2 8p3 8p5 8p6 8p7 8p8 8p9 9p0 10p0 11p0 12p0 13p0 15p0"
for tag in $INTACT; do
  dtag="shell$tag"
  # need both field-relaxed endpoints
  R=${dtag}_relaxed.xyz; P=${dtag}_prod_relaxed.xyz
  [ -f "$R" ] || R=run_${dtag}/${dtag}_relaxed.xyz
  [ -f "$P" ] || P=run_prod_${tag}/${dtag}_prod_relaxed.xyz
  if [ ! -f "$R" ] || [ ! -f "$P" ]; then echo "SKIP $dtag (missing endpoint: R=$([ -f "$R" ]&&echo ok||echo NO) P=$([ -f "$P" ]&&echo ok||echo NO))"; continue; fi
  mkdir -p run_nebv2_$tag
  cp "$R" run_nebv2_$tag/${dtag}_relaxed.xyz
  cp "$P" run_nebv2_$tag/${dtag}_prod_relaxed.xyz
  cp ${dtag}_charges.txt run_nebv2_$tag/ 2>/dev/null || cp run_${dtag}/${dtag}_charges.txt run_nebv2_$tag/
  # write v2 script fresh
  { cat <<'PYEOF'
import sys, openmm
from ash import Fragment, ORCATheory, OpenMMTheory, QMMMTheory, NEBTS
name=sys.argv[1]; RUN=(len(sys.argv)>2 and sys.argv[2]=="run")
ORCADIR="/home/apps2/ORCA/6.0.1"
r_coords="\n".join(open("%s_relaxed.xyz"%name).read().splitlines()[2:])
p_coords="\n".join(open("%s_prod_relaxed.xyz"%name).read().splitlines()[2:])
mmcharges=[float(x) for x in open("%s_charges.txt"%name).read().split(",")]
fragR=Fragment(coordsstring=r_coords, charge=-2, mult=1)
fragP=Fragment(coordsstring=p_coords, charge=-2, mult=1)
els=[a.split()[0] for a in r_coords.strip().split("\n")]
print(">> %s NEB v2: FIELD-RELAXED endpoints. %d atoms (24 QM + %d MM), MM net %+.2f"%(name,fragR.numatoms,fragR.numatoms-24,sum(mmcharges)))
assert fragR.numatoms==fragP.numatoms==len(mmcharges)
LJ={"C":(3.40,0.086),"N":(3.25,0.170),"O":(2.96,0.210),"H":(1.06,0.016)}
orca=ORCATheory(orcadir=ORCADIR,orcasimpleinput="! B3LYP D3BJ def2-SVP def2/J RIJCOSX CPCM TightSCF",
    orcablocks="%cpcm epsilon 4.0 end\n%scf MaxIter 300 Guess PModel end\n%geom coordsys cartesian end",
    numcores=8,autostart=False)
mm=OpenMMTheory(fragment=fragR,dummysystem=True,platform="CPU",numcores=1,autoconstraints=None,rigidwater=False)
lj=openmm.CustomBondForce("4*eps*((sig/r)^12 - (sig/r)^6)")
lj.addPerBondParameter("sig");lj.addPerBondParameter("eps");lj.setUsesPeriodicBoundaryConditions(False)
ang=openmm.unit.angstrom;kcal=openmm.unit.kilocalorie_per_mole
for i in range(24):
    si,ei=LJ[els[i]]
    for j in range(24,fragR.numatoms):
        sj,ej=LJ[els[j]]
        sig=((si+sj)/2*ang).value_in_unit(openmm.unit.nanometer);eps=(((ei*ej)**0.5)*kcal).value_in_unit(openmm.unit.kilojoule_per_mole)
        lj.addBond(i,j,[sig,eps])
lj.setForceGroup(11);mm.system.addForce(lj)
qmmm=QMMMTheory(qm_theory=orca,mm_theory=mm,fragment=fragR,qmatoms=list(range(24)),charges=mmcharges,
    embedding="elstat",qm_charge=-2,qm_mult=1,numcores=8)
if not RUN:
    print("=== DRY RUN OK %s v2 ==="%name); sys.exit(0)
NEBTS(reactant=fragR, product=fragP, theory=qmmm, images=12, CI=True,
      charge=-2, mult=1, printlevel=2, maxiter=200, free_end=True,
      ActiveRegion=True, actatoms=list(range(24)))
print(">> NEB DONE for %s"%name)
PYEOF
  } > run_nebv2_$tag/neb_v2.py
  { cat <<PBS
#!/bin/bash
#PBS -N nebv2_$tag
#PBS -l select=1:ncpus=8:mem=32gb
#PBS -l walltime=72:00:00
#PBS -M 18660916@sun.ac.za -m ae
#PBS -o nebv2_$tag.stdout
#PBS -e nebv2_$tag.stderr
cd \$PBS_O_WORKDIR
source /apps/mambaforge/etc/profile.d/conda.sh
conda activate \$HOME/envs/ash
export PYTHONNOUSERSITE=1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PATH=/apps/openmpi/4.1.1/bin:\$PATH
export LD_LIBRARY_PATH=/home/apps2/ORCA/6.0.1/lib:/apps/openmpi/4.1.1/lib:/apps/mambaforge/envs/medaka/lib:\$LD_LIBRARY_PATH
python3 neb_v2.py $dtag run > nebv2_${tag}.log 2>&1
PBS
  } > run_nebv2_$tag/run_nebv2_$tag.pbs
  ( cd run_nebv2_$tag && qsub run_nebv2_$tag.pbs )
  echo "submitted nebv2_$tag"
done
echo "Stage 2 (v2 NEB) submitted."
