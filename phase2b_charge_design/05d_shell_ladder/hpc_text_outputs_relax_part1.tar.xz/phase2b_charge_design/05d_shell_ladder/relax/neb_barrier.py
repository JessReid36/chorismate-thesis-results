# NEB-TS barrier under a fixed charge field (GOCAT-style: whole connected path, not endpoint difference).
# Band: reactant -> TS -> product, optimised TOGETHER under the same surrogate charge field.
# Barrier = E(highest image / CI-TS) - E(reactant image), all on ONE connected path.
# Frame-lock guards (B1): Quatern no + coordsys cartesian so the substrate can't slide vs the fixed charges.
import sys, openmm
from ash import Fragment, ORCATheory, OpenMMTheory, QMMMTheory, NEBTS
name=sys.argv[1]; RUN=(len(sys.argv)>2 and sys.argv[2]=="run")
ORCADIR="/home/apps2/ORCA/6.0.1"
# reactant design = substrate(24, reactant geom) + surrogate bodies. product design = same bodies + product substrate.
r_coords="\n".join(open("%s_coords.xyz"%name).read().splitlines()[2:])           # reactant substrate + bodies
mmcharges=[float(x) for x in open("%s_charges.txt"%name).read().split(",")]
# build the PRODUCT-substrate + same bodies design (bodies identical, swap substrate block)
rd=open("%s_coords.xyz"%name).read().splitlines(); n=int(rd[0].split()[0]); body=rd[2+24:2+n]
prod=open("product.xyz").read().splitlines()[2:26]
open("%s_prod_coords.xyz"%name,"w").write("%d\n%s product\n%s\n"%(n,name,"\n".join(prod+body)))

fragR=Fragment(coordsstring=r_coords, charge=-2, mult=1)
fragP=Fragment(xyzfile="%s_prod_coords.xyz"%name, charge=-2, mult=1)
els=[a.split()[0] for a in r_coords.strip().split("\n")]
print(">> %s NEB: %d atoms (24 QM + %d MM bodies), MM net %+.2f"%(name,fragR.numatoms,fragR.numatoms-24,sum(mmcharges)))
assert len(mmcharges)==fragR.numatoms

LJ={"C":(3.40,0.086),"N":(3.25,0.170),"O":(2.96,0.210),"H":(1.06,0.016)}
# frame-lock + field-preserving ORCA blocks (B1 guards)
orca=ORCATheory(orcadir=ORCADIR,
    orcasimpleinput="! B3LYP D3BJ def2-SVP def2/J RIJCOSX CPCM TightSCF",
    orcablocks="%cpcm epsilon 4.0 end\n%scf MaxIter 300 Guess PModel end\n%geom coordsys cartesian end",
    numcores=8,autostart=False)
def build_mm(frag):
    mm=OpenMMTheory(fragment=frag,dummysystem=True,platform="CPU",numcores=1,autoconstraints=None,rigidwater=False)
    lj=openmm.CustomBondForce("4*eps*((sig/r)^12 - (sig/r)^6)")
    lj.addPerBondParameter("sig");lj.addPerBondParameter("eps");lj.setUsesPeriodicBoundaryConditions(False)
    ang=openmm.unit.angstrom;kcal=openmm.unit.kilocalorie_per_mole
    for i in range(24):
        si,ei=LJ[els[i]]
        for j in range(24,frag.numatoms):
            sj,ej=LJ[els[j]]
            sig=((si+sj)/2*ang).value_in_unit(openmm.unit.nanometer);eps=(((ei*ej)**0.5)*kcal).value_in_unit(openmm.unit.kilojoule_per_mole)
            lj.addBond(i,j,[sig,eps])
    lj.setForceGroup(11);mm.system.addForce(lj); return mm
mm=build_mm(fragR)
qmmm=QMMMTheory(qm_theory=orca,mm_theory=mm,fragment=fragR,qmatoms=list(range(24)),charges=mmcharges,
    embedding="elstat",qm_charge=-2,qm_mult=1,numcores=8)
if not RUN:
    print("=== DRY RUN OK %s: NEB band R->P under field, %d MM bodies frozen, frame-locked ==="%(name,fragR.numatoms-24)); sys.exit(0)
# NEB-TS: optimise the whole band, climbing image finds the TS. Frame-lock via ORCA %neb (Quatern no).
# ASH NEBTS is ASH's OWN band engine (IDPP interp), NOT ORCA's %neb -> no Quatern keyword.
# Frame is anchored by the FROZEN MM surrogate bodies (they are physical atoms in the same system;
# since they don't move, the substrate cannot slide relative to the fixed charges). Restrict motion to
# the 24-atom substrate via ActiveRegion so the MM bodies stay put and pin the lab frame.
# Seed the TS guess from ts.xyz (build TS-substrate + same bodies design) for reliable convergence.
rd=open("%s_coords.xyz"%name).read().splitlines(); n=int(rd[0].split()[0]); body=rd[2+24:2+n]
tss=open("ts.xyz").read().splitlines()[2:26]
open("%s_ts_coords.xyz"%name,"w").write("%d\n%s ts guess\n%s\n"%(n,name,"\n".join(tss+body)))
NEBTS(reactant=fragR, product=fragP, theory=qmmm, images=12, CI=True,
      charge=-2, mult=1, printlevel=2,
      ActiveRegion=True, actatoms=list(range(24)),         # only substrate moves; MM bodies frozen -> frame anchored
      TS_guess_file="%s_ts_coords.xyz"%name)               # seed the climbing image from our TS geometry
print(">> NEB DONE for %s"%name)
