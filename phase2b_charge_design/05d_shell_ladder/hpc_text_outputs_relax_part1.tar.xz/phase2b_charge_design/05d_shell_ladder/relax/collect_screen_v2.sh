#!/bin/bash
# GOCAT gate from converged geometries + logs (bypasses the buggy _screen.txt).
# PASS = both endpoints CONVERGED (log: "optimization converged") AND INTACT (O3-C4<2.2 in screened.xyz)
echo "design | R:O3C4 C1C6 conv | P:O3C4 C1C6 conv | GOCAT verdict"
echo "-------|-------------------|-------------------|-------------"
for tag in 2p0 7p0 7p1 7p2 7p3 7p4 7p5 7p6 7p7 7p8 7p9 8p0 8p1 8p2 8p3 8p5 8p6 8p7 8p8 8p9 9p0 10p0 11p0 12p0 13p0 15p0; do
  rx=run_screen_${tag}_reactant/shell${tag}_reactant_screened.xyz
  px=run_screen_${tag}_product/shell${tag}_product_screened.xyz
  rlog=run_screen_${tag}_reactant/scr_${tag}_reactant.log
  plog=run_screen_${tag}_product/scr_${tag}_product.log
  geom(){ python3 -c "
import math,sys
try:
 L=open('$1').read().splitlines();a=[[float(v) for v in L[2+i].split()[1:4]] for i in range(24)]
 d=lambda i,j: math.sqrt(sum((a[i][k]-a[j][k])**2 for k in range(3)))
 print('%.3f %.3f'%(d(7,8),d(0,12)))
except: print('NA NA')
"; }
  conv(){ [ -f "$1" ] && { grep -qi "optimization converged" "$1" && echo 1 || echo 0; } || echo -; }
  if [ ! -f "$rx" ] && [ ! -f "$px" ]; then printf '%-6s| running\n' "$tag"; continue; fi
  rg=$(geom "$rx"); pg=$(geom "$px"); rc=$(conv "$rlog"); pc=$(conv "$plog")
  ro=$(echo $rg|cut -d' ' -f1); po=$(echo $pg|cut -d' ' -f1)
  python3 -c "
ro='$ro'; po='$po'; rc='$rc'; pc='$pc'; rg='$rg'; pg='$pg'
try: rint = float(ro)<2.2
except: rint=False
try: pint = float(po)<2.2
except: pint=False
rok = rc=='1' and rint; pok = pc=='1' and pint
if '$rx' and rc=='-': v='R-running'
elif rok and pok: v='PASS -> NEB'
else:
  f=[]
  if rc=='0': f.append('R-noconv')
  if not rint and ro!='NA': f.append('R-broken')
  if pc=='0': f.append('P-noconv')
  if not pint and po!='NA': f.append('P-broken')
  if pc=='-': f.append('P-running')
  v='FAIL('+','.join(f)+')' if f else 'partial'
print('%-6s| %s  %s   | %s  %s   | %s'%('$tag',rg,rc,pg,pc,v))
"
done
