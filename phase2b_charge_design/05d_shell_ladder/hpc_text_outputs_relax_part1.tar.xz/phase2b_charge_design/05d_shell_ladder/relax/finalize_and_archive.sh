#!/bin/bash
# Run from 05d_shell_ladder/relax. Archives all results + writes the summary + stages for commit.
set +e
STAMP=$(date +%Y%m%d)
ARCH=~/phase2b_ladder_archive_$STAMP
mkdir -p $ARCH/{neb_pass,screens,ladder_relax,controls,summaries}

echo "=== 1. NEB PASS results (bands, MEP, image energies, logs) ==="
for tag in 2p0 7p1 7p3 7p4 7p6 7p8 8p1 8p2 8p5 8p6 8p9 12p0 13p0 15p0; do
  d=run_nebP_$tag
  [ -d "$d" ] || continue
  mkdir -p $ARCH/neb_pass/$tag
  # keep: log, ASH_NEB.result, MEP, final band images - NOT the bulky per-image ORCA scratch
  cp $d/nebP_$tag.log $ARCH/neb_pass/$tag/ 2>/dev/null
  cp $d/ASH_NEB.result $ARCH/neb_pass/$tag/ 2>/dev/null
  cp $d/knarr_MEP_FULL.xyz $ARCH/neb_pass/$tag/ 2>/dev/null
  cp $d/${tag}_relaxed.xyz $d/shell${tag}_relaxed.xyz $ARCH/neb_pass/$tag/ 2>/dev/null
  cp $d/*_prod_relaxed.xyz $ARCH/neb_pass/$tag/ 2>/dev/null
  # extract the final band table into a clean file
  grep -A16 "Image  Energy(Eh)" $d/nebP_$tag.log | tail -17 > $ARCH/neb_pass/$tag/final_band.txt 2>/dev/null
done

echo "=== 2. GOCAT screen results (converged endpoints + verdicts) ==="
for tag in 2p0 7p0 7p1 7p2 7p3 7p4 7p5 7p6 7p7 7p8 7p9 8p0 8p1 8p2 8p3 8p5 8p6 8p7 8p8 8p9 9p0 10p0 11p0 12p0 13p0 15p0; do
  for ep in reactant product; do
    s=run_screen_${tag}_${ep}
    [ -d "$s" ] || continue
    mkdir -p $ARCH/screens/${tag}_${ep}
    cp $s/shell${tag}_${ep}_screened.xyz $ARCH/screens/${tag}_${ep}/ 2>/dev/null
    # keep just the tail of the log (convergence line), not the whole multi-GB thing
    tail -40 $s/scr_${tag}_${ep}.log > $ARCH/screens/${tag}_${ep}/screen_tail.log 2>/dev/null
  done
done

echo "=== 3. Geometry ladder relaxations (the field-relaxed reactants) ==="
for s in run_shell*; do
  [ -d "$s" ] || continue
  tag=${s#run_shell}
  mkdir -p $ARCH/ladder_relax/$tag
  cp $s/shell${tag}_relaxed.xyz $ARCH/ladder_relax/$tag/ 2>/dev/null
  cp $s/${tag}_relaxed.xyz $ARCH/ladder_relax/$tag/ 2>/dev/null
done

echo "=== 4. Controls ==="
cp run_ctrl_bare/bare_control_relaxed.xyz $ARCH/controls/ 2>/dev/null
cp run_ctrl_shell2/shell2p0ctrl_relaxed.xyz $ARCH/controls/ 2>/dev/null

echo "=== 5. tarball ==="
cd ~
tar czf phase2b_ladder_archive_$STAMP.tar.gz phase2b_ladder_archive_$STAMP/
echo "ARCHIVE: ~/phase2b_ladder_archive_$STAMP.tar.gz"
du -sh ~/phase2b_ladder_archive_$STAMP.tar.gz
echo ""
echo "Download it to your PC with (run on your PC):"
echo "  scp 18660916@hpc1.sun.ac.za:~/phase2b_ladder_archive_$STAMP.tar.gz ~/Desktop/"
