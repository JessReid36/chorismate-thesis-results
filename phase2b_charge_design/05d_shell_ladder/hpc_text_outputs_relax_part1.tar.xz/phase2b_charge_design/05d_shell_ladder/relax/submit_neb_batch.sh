#!/bin/bash
# Run from 05d_shell_ladder/relax. Submits NEB-under-field for the near-window intact designs.
# 8p0 already running - not included. Needs each shell's design coords/charges + product.xyz here.
set -e
CANDS="7p4 7p3 7p7 7p0 9p0"
cp ../../01_geometry/product.xyz . 2>/dev/null || true

for tag in $CANDS; do
  dtag="shell$tag"
  if [ ! -f "${dtag}_coords.xyz" ]; then
    # recover from the reactant run dir if needed
    [ -f "run_${dtag}/${dtag}_coords.xyz" ] && cp run_${dtag}/${dtag}_coords.xyz run_${dtag}/${dtag}_charges.txt . 2>/dev/null || { echo "SKIP $dtag (no coords)"; continue; }
  fi
  mkdir -p run_neb_$tag
  cp ${dtag}_coords.xyz ${dtag}_charges.txt product.xyz run_neb_$tag/
  # write the VERIFIED neb_barrier.py fresh into the run dir
  { cat <<'PYEOF'
import sys, openmm
from ash import Fragment, ORCATheory, OpenMMTheory, QMMMTheory, NEBTS
name=sys.argv[1]; RUN=(len(sys.argv)>2 and sys.argv[2]=="run")
ORCADIR="/home/apps2/ORCA/6.0.1"
r_coords="\n".join(open("%s_coords.xyz"%name).read().splitlines()[2:])
mmcharges=[float(x) for x in open("%s_charges.txt"%name).read().split(",")]
rd=open("%s_coords.xyz"%name).read().splitlines(); n=int(rd[0].split()[0]); body=rd[2+24:2+n]
prod=open("product.xyz").read().splitlines()[2:26]
open("%s_prod_coords.xyz"%name,"w").write("%d\n%s product\n%s\n"%(n,name,"\n".join(prod+body)))
fragR=Fragment(coordsstring=r_coords, charge=-2, mult=1)
fragP=Fragment(xyzfile="%s_prod_coords.xyz"%name, charge=-2, mult=1)
els=[a.split()[0] for a in r_coords.strip().split("\n")]
print(">> %s NEB: %d atoms (24 QM + %d MM bodies), MM net %+.2f"%(name,fragR.numatoms,fragR.numatoms-24,sum(mmcharges)))
assert len(mmcharges)==fragR.numatoms
LJ={"C":(3.40,0.086),"N":(3.25,0.170),"O":(2.96,0.210),"H":(1.06,0.016)}
orca=ORCATheory(orcadir=ORCADIR,
    orcasimpleinput="! B3LYP D3BJ def2-SVP def2/J RIJCOSX CPCM TightSCF",
    orcablocks="%cpcm epsilon 4.0 end\n%scf MaxIter 300 Guess PModel end\n%geom coordsys cartesian end",
    numcores=8,autostart=False)
mm=OpenMMTheory(fragment=fragR,dummysystem=True,platform="CPU",numcores=1,autoconstraints=None,rigidwater=False)
lj=openmm.CustomBondForce("4*eps*((sig/r)^12 - (sig/r)^6)")
lj.addPerBondParameter("sig");lj.addPerBondParameter("eps");lj.setUsesPeriodicBoundaryConditions(False)
ang=openmm.unit.angstrom;kcal=openmm.unit.kilocalorie_per_mole
for i in range(24):
    si,ei=LJ[els[i]]
    for j in range(24,fragR.numatoms):
        sj,ej=LJ[els[j]]
        sig=((si+sj)/2*ang).value_in_unit(openmm.unit.nanometer);eps=(((ei*ej)**0.5)*kcal).value_in_unit(openmm.unit.kilojoule_per_mole)
        lj.addBond(i,j,[sig,eps])
lj.setForceGroup(11);mm.system.addForce(lj)
qmmm=QMMMTheory(qm_theory=orca,mm_theory=mm,fragment=fragR,qmatoms=list(range(24)),charges=mmcharges,
    embedding="elstat",qm_charge=-2,qm_mult=1,numcores=8)
if not RUN:
    print("=== DRY RUN OK %s: NEB band R->P under field, %d MM bodies frozen, frame-locked ==="%(name,fragR.numatoms-24)); sys.exit(0)
NEBTS(reactant=fragR, product=fragP, theory=qmmm, images=12, CI=True,
      charge=-2, mult=1, printlevel=2,
      ActiveRegion=True, actatoms=list(range(24)))
print(">> NEB DONE for %s"%name)
PYEOF
  } > run_neb_$tag/neb_barrier.py
  # PBS
  { cat <<PBS
#!/bin/bash
#PBS -N neb_$tag
#PBS -l select=1:ncpus=8:mem=32gb
#PBS -l walltime=72:00:00
#PBS -M 18660916@sun.ac.za -m ae
#PBS -o neb_$tag.stdout
#PBS -e neb_$tag.stderr
cd \$PBS_O_WORKDIR
source /apps/mambaforge/etc/profile.d/conda.sh
conda activate \$HOME/envs/ash
export PYTHONNOUSERSITE=1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PATH=/apps/openmpi/4.1.1/bin:\$PATH
export LD_LIBRARY_PATH=/home/apps2/ORCA/6.0.1/lib:/apps/openmpi/4.1.1/lib:/apps/mambaforge/envs/medaka/lib:\$LD_LIBRARY_PATH
python3 neb_barrier.py $dtag run > neb_$tag.log 2>&1
PBS
  } > run_neb_$tag/run_neb_$tag.pbs
  # verify no stale TS_guess before submit
  if [ "$(grep -c TS_guess_file run_neb_$tag/neb_barrier.py)" != "0" ]; then echo "ABORT $tag: stale file"; continue; fi
  ( cd run_neb_$tag && qsub run_neb_$tag.pbs )
  echo "submitted neb_$tag"
done
echo "batch done."
