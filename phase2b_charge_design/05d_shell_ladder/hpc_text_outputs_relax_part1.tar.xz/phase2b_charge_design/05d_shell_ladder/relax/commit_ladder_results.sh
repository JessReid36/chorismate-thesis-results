#!/bin/bash
# Stage + commit the ladder/screen/NEB results. Run from the RESULTS repo root
# (~/Desktop/chorismate-thesis-results) on the Ubuntu PC AFTER copying files in.
# This is a template - review before running.
set +e
echo "This commits the shell-ladder + GOCAT-screen + NEB certified-negative result."
echo "Files to have staged in the results repo:"
echo "  05d_shell_ladder/SHELL_LADDER_NEB_RESULT.md"
echo "  05d_shell_ladder/screen_verdicts.txt   (the collect_screen_v3 output)"
echo "  05d_shell_ladder/neb_pass_bands/        (final_band.txt per PASS design)"
echo "  archive tarball reference"
echo ""
echo "Suggested commit (three-part discipline):"
echo "  git add 05d_shell_ladder/"
echo '  git commit -m "[retained-final] shell ladder 2-15A + GOCAT stationary-point screen + NEB: certified negative'
echo ""
echo "  - 30-design distance ladder: fragment close, push-open far, no robust window hit"
echo "  - controls: bare 3.538, bodies inert 3.367 (field effects attributable)"
echo "  - GOCAT screen (Eq 3.2/3.3): 14/26 fail (product shatters); pass designs all open reactants"
echo "  - NEB-under-field on pass designs: none converge (no valid path under field) -> no catalytic barrier"
echo "  - discrete uniform +-1 charges cannot catalyse at any distance; motivates fractional design"
echo '  - method lesson: barriers require connected NEB path between field-relaxed screened endpoints"'
