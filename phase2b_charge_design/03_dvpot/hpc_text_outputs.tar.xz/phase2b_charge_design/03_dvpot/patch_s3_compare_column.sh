#!/usr/bin/env bash
# patch_s3_compare_column.sh - fix the --compare branch of s3_dv_on_grid_v2.py.
#
# THE FAULT
#   Line 71 reads the difference potential from the comparison file by column
#   position, float(r[7]). That is Dv in the superseded 331-site dv_grid.tsv,
#   but V_TS in the production layout, whose columns are idx, x, y, z, shell,
#   standoff, V_R_Eh, V_TS_Eh, dv_Eh, dv_kcal_per_e. Comparing the def2-SVPD map
#   against dv_grid_v2.tsv therefore reported a "previous grid best single
#   charge" of -111.616 kcal/mol, which is the transition-state potential rather
#   than the difference.
#
#   The same fault was found and fixed in 04_compare_grids.py, where it produced
#   a gradient of 4.370 instead of 0.185. This is the second occurrence, so the
#   fix here selects by header name and fails loudly rather than guessing.

set -euo pipefail
[[ -f s3_dv_on_grid_v2.py ]] || { echo "run from the 03_dvpot directory"; exit 1; }
cp s3_dv_on_grid_v2.py s3_dv_on_grid_v2.py.bak

python3 - <<'PY'
from pathlib import Path
p = Path("s3_dv_on_grid_v2.py"); t = p.read_text()

old = '''            old = [l.split("\\t") for l in Path(compare).read_text().splitlines()[1:] if l.strip()]
            odv = [float(r[7]) for r in old]'''
new = '''            lines = [l.split("\\t") for l in Path(compare).read_text().splitlines() if l.strip()]
            hdr = [h.strip() for h in lines[0]]
            # Select by header name. Column 7 holds Dv in the superseded
            # 331-site dv_grid.tsv but V_TS in the production layout, and
            # positional indexing has produced two wrong results in this
            # project. Fail rather than guess.
            if "dv_Eh" in hdr:
                dcol = hdr.index("dv_Eh")
            elif "Dv" in hdr:
                dcol = hdr.index("Dv")
            else:
                raise ValueError(f"no Dv column in {compare}; header is {hdr}")
            old = lines[1:]
            odv = [float(r[dcol]) for r in old]'''
assert old in t, "compare block not found - inspect the file by hand"
p.write_text(t.replace(old, new, 1))
print("patched: --compare now selects the Dv column by header name")
PY

echo
echo "Verify with:"
echo "  python3 s3_dv_on_grid_v2.py assemble grid_row_order.tsv vR_svpd.out \\"
echo "          vTS_svpd.out /tmp/check.tsv --compare dv_grid_v2.tsv"
echo "The comparison should now report a previous best single charge near"
echo "-3.85 kcal/mol, not -111.616."
