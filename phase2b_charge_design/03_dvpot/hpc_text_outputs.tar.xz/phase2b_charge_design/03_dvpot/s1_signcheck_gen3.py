#!/usr/bin/env python3
"""
s1_signcheck_gen3.py - Gen-3 sign-convention check for the difference potential.

Two modes, called in sequence by s1_signcheck_gen3.pbs:

  points <reactant.xyz> <out_bohr.xyz> <out_labels.tsv>
      Build the three physically motivated test points from the reactant
      geometry and write them in Bohr for orca_vpot.

  assemble <labels.tsv> <vR.out> <vTS.out> <out_table.tsv>
      Read the two potentials, form Dv = V_TS - V_R, print the table and
      decide PASS / FAIL.

The three points (same construction as the Gen-1/Gen-2 checks, so the
numbers are directly comparable):

  A  2.0 A beyond the ether oxygen O3, along C4 -> O3.
     This is where Arg90 sits in BsCM. Negative charge develops on O3 as the
     C4-O3 bond breaks, so a +1 cation here MUST be stabilising: Dv < 0.

  B  2.0 A beyond C6, along C1 -> C6.
     Charge is depleted in the forming-bond region, so the sign MUST invert
     here: Dv > 0. This is the negative control - without it, a Dv that was
     uniformly negative everywhere (a global offset, not a real differential)
     would still pass point A.

  C  3.0 A out of the reacting plane, above the midpoint of the two bonds.
     Reported for context; not part of the pass criterion.

Pass criterion: Dv(A) < 0 AND Dv(B) > 0. Both are required. One without the
other does not establish that Dv carries reaction-coordinate information.
"""

import math
import sys
from pathlib import Path

ANG2BOHR = 1.8897259886
HARTREE2KCAL = 627.5094740631

# 0-based indices from 00_admin/reacting_atoms.tsv
IDX = {"C1": 0, "O3": 7, "C4": 8, "C6": 12}

# Reference values from the earlier generations, for comparison only.
PRIOR = {
    "Gen 1 (placeholder)": {"A": -0.012167, "B": +0.002715, "C": -0.010865},
    "Gen 2 (realgeom, stale TS)": {"A": -0.012689, "B": +0.010556, "C": -0.006753},
}


def read_xyz(path):
    lines = Path(path).read_text().splitlines()
    n = int(lines[0].split()[0])
    coords = []
    for line in lines[2:2 + n]:
        p = line.split()
        coords.append((float(p[1]), float(p[2]), float(p[3])))
    return coords


def sub(a, b):
    return tuple(a[i] - b[i] for i in range(3))


def add(a, b):
    return tuple(a[i] + b[i] for i in range(3))


def scale(a, s):
    return tuple(x * s for x in a)


def norm(a):
    return math.sqrt(sum(x * x for x in a))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def build_points(geom_path, out_bohr, out_labels):
    xyz = read_xyz(geom_path)
    if len(xyz) != 24:
        sys.exit(f"FAIL: expected 24 atoms in {geom_path}, found {len(xyz)}")

    O3, C4 = xyz[IDX["O3"]], xyz[IDX["C4"]]
    C1, C6 = xyz[IDX["C1"]], xyz[IDX["C6"]]

    # Geometry sanity: confirm this really is the Gen-3 reactant.
    d_break = norm(sub(O3, C4))
    d_form = norm(sub(C1, C6))
    print(f"geometry check: break O3-C4 = {d_break:.3f} A, form C1-C6 = {d_form:.3f} A")
    print("                (Gen 3 reactant expects 1.472 / 3.124)")
    if abs(d_break - 1.472) > 0.02 or abs(d_form - 3.124) > 0.05:
        sys.exit("FAIL: geometry does not match the Gen-3 reactant - wrong file?")

    u = scale(sub(O3, C4), 1.0 / norm(sub(O3, C4)))
    pA = add(O3, scale(u, 2.0))

    u2 = scale(sub(C6, C1), 1.0 / norm(sub(C6, C1)))
    pB = add(C6, scale(u2, 2.0))

    mid = scale(add(add(O3, C4), add(C6, C1)), 0.25)
    nrm = cross(sub(C4, C6), sub(C1, O3))
    nrm = scale(nrm, 3.0 / (norm(nrm) or 1.0))
    pC = add(mid, nrm)

    pts = [("A_etherO_C-O_dir", pA),
           ("B_formingC6_dir", pB),
           ("C_out_of_plane_mid", pC)]

    with open(out_bohr, "w") as fh:
        fh.write(f"{len(pts)}\n")
        for _, p in pts:
            fh.write("  ".join(f"{c * ANG2BOHR:.10f}" for c in p) + "\n")

    with open(out_labels, "w") as fh:
        fh.write("label\tx_ang\ty_ang\tz_ang\n")
        for name, p in pts:
            fh.write(f"{name}\t{p[0]:.4f}\t{p[1]:.4f}\t{p[2]:.4f}\n")

    print(f"wrote {len(pts)} test points to {out_bohr} (Bohr) and {out_labels} (Angstrom)")


def read_vpot(path):
    vals = []
    for line in Path(path).read_text().splitlines():
        p = line.split()
        if len(p) >= 4:
            try:
                vals.append(float(p[-1]))
            except ValueError:
                pass
    return vals


def assemble(labels_path, vR_path, vTS_path, out_table):
    labels = [l.split("\t")[0]
              for l in Path(labels_path).read_text().splitlines()[1:]]
    vR, vTS = read_vpot(vR_path), read_vpot(vTS_path)

    if not (len(vR) == len(vTS) == len(labels)):
        sys.exit(f"FAIL: length mismatch - vR={len(vR)} vTS={len(vTS)} labels={len(labels)}")

    dv = {}
    print()
    print(f"{'point':24s} {'V_R (Eh)':>12s} {'V_TS (Eh)':>12s} "
          f"{'Dv (Eh)':>12s} {'Dv (kcal/mol per +1e)':>24s}")
    print("-" * 90)
    rows = []
    for lab, a, b in zip(labels, vR, vTS):
        d = b - a
        key = lab[0]
        dv[key] = d
        verdict = "STABILISING" if d < 0 else "destabilising"
        print(f"{lab:24s} {a:12.6f} {b:12.6f} {d:+12.6f} "
              f"{d * HARTREE2KCAL:+18.3f}   {verdict}")
        rows.append((lab, a, b, d))

    with open(out_table, "w") as fh:
        fh.write("label\tV_R_Eh\tV_TS_Eh\tDv_Eh\tDv_kcal_per_e\n")
        for lab, a, b, d in rows:
            fh.write(f"{lab}\t{a:.6f}\t{b:.6f}\t{d:.6f}\t{d * HARTREE2KCAL:.4f}\n")

    print()
    print("comparison with earlier generations (Eh):")
    print(f"{'':28s} {'A ether-O':>12s} {'B forming':>12s} {'C out-of-plane':>16s}")
    for name, p in PRIOR.items():
        print(f"  {name:26s} {p['A']:+12.6f} {p['B']:+12.6f} {p['C']:+16.6f}")
    print(f"  {'Gen 3 (this run)':26s} {dv['A']:+12.6f} {dv['B']:+12.6f} {dv['C']:+16.6f}")

    print()
    ok_A = dv["A"] < 0
    ok_B = dv["B"] > 0
    print(f"  point A (ether O, Arg90 position) Dv < 0 : {'PASS' if ok_A else 'FAIL'}")
    print(f"  point B (forming bond)            Dv > 0 : {'PASS' if ok_B else 'FAIL'}")

    if ok_A and ok_B:
        print()
        print("SIGN CHECK PASS on the Gen-3 geometry.")
        print("A +1 cation beyond the ether oxygen lowers the barrier (the Arg90 role),")
        print("and the sign inverts in the forming-bond region. Dv therefore carries")
        print("genuine reaction-coordinate information, not a uniform offset, and the")
        print("convention used by the charge-selection objective is correct.")
        return 0

    print()
    print("SIGN CHECK FAIL - do not proceed to charge selection.")
    print("Investigate the subtraction order and the units before anything downstream.")
    return 1


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    mode = sys.argv[1]
    if mode == "points":
        build_points(*sys.argv[2:5])
    elif mode == "assemble":
        sys.exit(assemble(*sys.argv[2:6]))
    else:
        sys.exit(f"unknown mode: {mode}")


if __name__ == "__main__":
    main()
