#!/usr/bin/env bash
#PBS -N cm_s15bdens
#PBS -l select=1:ncpus=1:mem=8gb
#PBS -l walltime=04:00:00
#PBS -m ae
#PBS -M 18660916@sun.ac.za
#PBS -j oe
#PBS -o /home/18660916/system_development/phase2.2/s15b_density/s15b_regen.pbs.out
#
# s15b_regen_density.sh - write the .scfp density files that orca_vpot needs, WITHOUT
# repeating any SCF.
#
# WHY THIS IS NEEDED
# orca_vpot takes both a .gbw and a .scfp. The step-19 in vacuo single points
# (s8_invacuo_new.pbs) were written to produce ENERGIES, so they did not request
# KeepDens and no .scfp exists. Phase 2b's own single points DO use KeepDens
# (phase2b_charge_design/02_singlepoints/sp_ts.inp begins
#   "! B3LYP D3BJ def2-SVP def2/J RIJCOSX CPCM KeepDens")
# so the convention already exists in this project; it simply was not applied to the
# step-19 runs.
#
# WHY NO SCF IS REPEATED
# MORead reads the converged orbitals from the existing .gbw and NoIter performs zero
# SCF iterations, so the density written is the one those orbitals define. The single
# points are not redone and nothing about the committed energies changes.
#
# THE CHECK THAT IT WORKED
# Because the orbitals are unchanged, the energy printed by the zero-iteration job must
# equal the committed one to numerical precision. Any frame where it does not is
# reported and excluded rather than silently used - a mismatch would mean the .gbw does
# not correspond to the geometry, and the resulting potential map would be wrong in a
# way no downstream diagnostic could detect.
#
# NOTE ON CPCM. The Phase 2b input above carries CPCM at epsilon 4. This job does NOT,
# because the Phase 2.2 environment decision removes the continuum: [D2018] never runs
# charges and COSMO together, and [B2021] uses explicit molecules with no continuum at
# all. The density here is the bare in vacuo one, matching the design environment and
# matching the committed step-19 single points whose orbitals it reads.

set -uo pipefail
ORCA=/home/apps2/ORCA/6.0.1
ROOT=/home/18660916/system_development
VAC="$ROOT/05_qmmm/20_invacuo"
WORK="$ROOT/phase2.2/s15b_density"

export PATH="/apps/openmpi/4.1.1/bin:$PATH"
export LD_LIBRARY_PATH="$ORCA/lib:/apps/openmpi/4.1.1/lib:/apps/mambaforge/envs/medaka/lib:${LD_LIBRARY_PATH:-}"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1

mkdir -p "$WORK"; cd "$WORK" || exit 1
if ! mkdir .running 2>/dev/null; then echo "FAIL: another job holds .running"; exit 1; fi
SCRATCH="${TMPDIR:-/tmp}/orca_$$"; mkdir -p "$SCRATCH"
trap 'rm -rf "$SCRATCH"; rmdir "$WORK/.running" 2>/dev/null' EXIT
echo "host=$(hostname) start=$(date) scratch=$SCRATCH"
echo

FRAMES="20000 21634 23268 24883 26495 33320 34991 36665 38344 40485 41786 42436 43087 43738 45688 46990 47641 48292 49592 50892 52192 53493"
echo "frames: $FRAMES"
echo

ok=0; bad=0; skip=0
for f in $FRAMES; do
  for tag in R TS; do
    b="${f}_${tag}"
    gbw="$VAC/sp_${b}.gbw"
    xyz="$VAC/${b}.xyz"
    ref="$VAC/sp_${b}.out"

    if [ ! -s "$gbw" ] || [ ! -s "$xyz" ] || [ ! -s "$ref" ]; then
      echo "  MISSING inputs for $b"; bad=$((bad+1)); continue
    fi
    if [ -s "$VAC/sp_${b}.scfp" ]; then
      echo "  $b: .scfp already present"; skip=$((skip+1)); continue
    fi

    d="$SCRATCH/$b"; rm -rf "$d"; mkdir -p "$d"
    cp "$gbw" "$d/ref.gbw"; cp "$xyz" "$d/"

    # zero-iteration job: read the converged orbitals, write the density, no SCF
    cat > "$d/dens_${b}.inp" <<EOF
! B3LYP D3BJ def2-SVP def2/J RIJCOSX MORead NoIter KeepDens
%maxcore 3000
%moinp "ref.gbw"
* xyzfile -2 1 ${b}.xyz
EOF

    ( cd "$d" && "$ORCA/orca" "dens_${b}.inp" > "dens_${b}.out" 2>&1 </dev/null )

    if ! grep -q "TERMINATED NORMALLY" "$d/dens_${b}.out"; then
      echo "  FAILED $b"; tail -3 "$d/dens_${b}.out" | sed 's/^/      /'; bad=$((bad+1))
      continue
    fi

    # the energy must reproduce the committed one, since the orbitals are unchanged
    enew=$(grep "FINAL SINGLE POINT ENERGY" "$d/dens_${b}.out" | tail -1 | awk '{print $NF}')
    eold=$(grep "FINAL SINGLE POINT ENERGY" "$ref" | tail -1 | awk '{print $NF}')
    same=$(python3 -c "print(abs(float('$enew')-float('$eold')) < 1e-6)" 2>/dev/null)
    if [ "$same" != "True" ]; then
      echo "  ENERGY MISMATCH $b: new $enew vs committed $eold - NOT using this density"
      bad=$((bad+1)); rm -rf "$d"; continue
    fi

    # ORCA names the density after the input; copy it back under the expected name
    if [ -s "$d/dens_${b}.scfp" ]; then
      cp "$d/dens_${b}.scfp" "$VAC/sp_${b}.scfp"
      echo "  $b: ok, E = $enew Eh, .scfp written"
      ok=$((ok+1))
    else
      echo "  NO .scfp produced for $b despite KeepDens"
      ls "$d" | sed 's/^/      /'
      bad=$((bad+1))
    fi
    rm -rf "$d"
  done
done

echo
echo "written=$ok already_present=$skip failed_or_missing=$bad"
echo "end=$(date)"
echo
echo "next, if written+already_present covers the frames you need:"
echo "  python3 phase2.2/s15_dv_matrix.py prepare <grid.tsv> phase2.2/s15_dv"
echo "  qsub phase2.2/s15_dv/s15_dv.pbs"
