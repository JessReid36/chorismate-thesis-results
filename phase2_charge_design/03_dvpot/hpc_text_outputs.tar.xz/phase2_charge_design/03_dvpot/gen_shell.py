#!/usr/bin/env python3
import numpy as np
lines=open('/home/18660916/system_development/phase2_charge_design/01_substrate/reactant.xyz').read().splitlines()[2:]
atoms=np.array([[float(x) for x in l.split()[1:4]] for l in lines[:24]])
cen=atoms.mean(0)
def fib(n):
    i=np.arange(n); phi=np.pi*(3-np.sqrt(5)); y=1-2*(i+0.5)/n
    r=np.sqrt(np.maximum(0,1-y*y)); th=phi*i
    return np.stack([r*np.cos(th),y,r*np.sin(th)],axis=1)
N=12000; dirs=fib(N); STANDOFF=2.5; rel=atoms-cen
shell=np.array([cen+d*((rel@d).max()+STANDOFF) for d in dirs])
np.savez('shell_mesh.npz', shell=shell, dirs=dirs, cen=cen, standoff=STANDOFF)
ANG2BOHR=1.8897259886
with open('shell_bohr.xyz','w') as f:
    f.write(f"{len(shell)}\n")
    for x,y,z in shell: f.write(f"{x*ANG2BOHR:.8f} {y*ANG2BOHR:.8f} {z*ANG2BOHR:.8f}\n")
print(f"wrote shell_bohr.xyz ({N} pts); standoff {STANDOFF} A")
