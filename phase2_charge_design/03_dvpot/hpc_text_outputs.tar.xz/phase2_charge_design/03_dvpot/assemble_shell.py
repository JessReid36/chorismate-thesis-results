#!/usr/bin/env python3
import numpy as np
from pathlib import Path
def rd(f):
    v=[]
    for ln in Path(f).read_text().splitlines():
        p=ln.split()
        if len(p)>=4:
            try: v.append(float(p[-1]))
            except: pass
    return np.array(v)
vR=rd("vR_shell.out"); vTS=rd("vTS_shell.out")
m=np.load("shell_mesh.npz")
shell=m["shell"]; dirs=m["dirs"]; cen=m["cen"]
assert len(vR)==len(vTS)==len(shell), f"{len(vR)}/{len(vTS)}/{len(shell)}"
dv=vTS-vR
np.savez("shell_dv.npz", shell=shell, dirs=dirs, cen=cen, dv=dv, standoff=m["standoff"])
print(f"shell Dv: {len(dv)} points, range {dv.min():+.5f} to {dv.max():+.5f} Ha")
print(f"  cation-fav (Dv<0): {(dv<0).sum()}, anion-fav (Dv>0): {(dv>0).sum()}")
