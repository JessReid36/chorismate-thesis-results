#!/usr/bin/env python3
import numpy as np
lines=open('/home/18660916/system_development/phase2_charge_design/01_substrate/reactant.xyz').read().splitlines()[2:]
atoms=np.array([[float(x) for x in l.split()[1:4]] for l in lines[:24]])
cen=atoms.mean(0); rel=atoms-cen
def fib(n):
    i=np.arange(n); phi=np.pi*(3-np.sqrt(5)); y=1-2*(i+0.5)/n
    r=np.sqrt(np.maximum(0,1-y*y)); th=phi*i
    return np.stack([r*np.cos(th),y,r*np.sin(th)],axis=1)
standoffs=[2.0,3.0,4.0]; N=1500
allpts=[]; layer_index=[]; meta={}
for si,so in enumerate(standoffs):
    dirs=fib(N); shell=np.array([cen+d*((rel@d).max()+so) for d in dirs])
    meta[f'dirs_{si}']=dirs; meta[f'shell_{si}']=shell
    for p in shell: allpts.append(p); layer_index.append(si)
allpts=np.array(allpts); layer_index=np.array(layer_index)
np.savez('layers_meta.npz', standoffs=np.array(standoffs), layer_index=layer_index, allpts=allpts, cen=cen, **meta)
ANG2BOHR=1.8897259886
with open('layers_bohr.xyz','w') as f:
    f.write(f"{len(allpts)}\n")
    for x,y,z in allpts: f.write(f"{x*ANG2BOHR:.8f} {y*ANG2BOHR:.8f} {z*ANG2BOHR:.8f}\n")
print(f"wrote layers_bohr.xyz ({len(allpts)} pts, 3 layers) + layers_meta.npz")
