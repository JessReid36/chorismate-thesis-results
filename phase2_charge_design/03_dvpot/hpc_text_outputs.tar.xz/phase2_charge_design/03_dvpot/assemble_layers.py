#!/usr/bin/env python3
import numpy as np
from pathlib import Path
def rd(f):
    v=[]
    for ln in Path(f).read_text().splitlines():
        p=ln.split()
        if len(p)>=4:
            try: v.append(float(p[-1]))
            except: pass
    return np.array(v)
vR=rd("vR_layers.out"); vTS=rd("vTS_layers.out")
m=np.load("layers_meta.npz")
li=m["layer_index"]; standoffs=m["standoffs"]
assert len(vR)==len(vTS)==len(li), f"{len(vR)}/{len(vTS)}/{len(li)}"
dv=vTS-vR
out={'standoffs':standoffs,'layer_index':li,'cen':m['cen'],'dv':dv,'allpts':m['allpts']}
for i in range(len(standoffs)):
    out[f'dirs_{i}']=m[f'dirs_{i}']; out[f'shell_{i}']=m[f'shell_{i}']
    mask=li==i
    print(f"layer {standoffs[i]} A: {mask.sum()} pts, Dv {dv[mask].min():+.5f} to {dv[mask].max():+.5f}")
np.savez("layers_dv.npz", **out)
print("wrote layers_dv.npz")
