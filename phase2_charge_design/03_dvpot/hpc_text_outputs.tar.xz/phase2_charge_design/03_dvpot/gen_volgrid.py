#!/usr/bin/env python3
import numpy as np
ANG2BOHR = 1.8897259886
lo = np.array([15.4874, 31.9110, 50.5883])
hi = np.array([27.6676, 48.8620, 64.3810])
spacing = 0.40
nx, ny, nz = 32, 44, 36
xs = lo[0] + spacing*np.arange(nx)
ys = lo[1] + spacing*np.arange(ny)
zs = lo[2] + spacing*np.arange(nz)
pts = []
for ix in range(nx):
    for iy in range(ny):
        for iz in range(nz):
            pts.append((xs[ix], ys[iy], zs[iz]))
pts = np.array(pts)
print(f"generated {len(pts)} grid points ({nx}x{ny}x{nz})")
with open("volgrid_bohr.xyz","w") as f:
    f.write(f"{len(pts)}\n")
    for x,y,z in pts:
        f.write(f"{x*ANG2BOHR:.8f} {y*ANG2BOHR:.8f} {z*ANG2BOHR:.8f}\n")
np.savez("volgrid_meta.npz", pts_ang=pts, shape=np.array([nx,ny,nz]),
         lo=lo, hi=hi, spacing=spacing)
print("wrote volgrid_bohr.xyz + volgrid_meta.npz")
