#!/usr/bin/env python3
import numpy as np
from pathlib import Path
def read_vpot(f):
    vals=[]
    for ln in Path(f).read_text().splitlines():
        p=ln.split()
        if len(p)>=4:
            try: vals.append(float(p[-1]))
            except ValueError: pass
    return np.array(vals)
vR = read_vpot("vR_vol.out")
vTS = read_vpot("vTS_vol.out")
meta = np.load("volgrid_meta.npz")
nx,ny,nz = meta["shape"]
assert len(vR)==len(vTS)==nx*ny*nz, f"len mismatch {len(vR)}/{len(vTS)} vs {nx*ny*nz}"
dv = (vTS - vR).reshape(nx,ny,nz)
np.savez("volgrid_dv.npz", dv=dv, shape=meta["shape"], lo=meta["lo"], hi=meta["hi"],
         spacing=meta["spacing"], vR=vR.reshape(nx,ny,nz), vTS=vTS.reshape(nx,ny,nz))
print(f"assembled Dv volume {nx}x{ny}x{nz}")
print(f"  Dv range: {dv.min():+.6f} to {dv.max():+.6f} Ha")
print(f"  cation-favorable (Dv<0): {(dv<0).sum():,} voxels; anion (Dv>0): {(dv>0).sum():,}")
print(f"  strong cation (Dv<-0.004): {(dv<-0.004).sum():,}; strong anion (Dv>0.004): {(dv>0.004).sum():,}")
print("wrote volgrid_dv.npz")
