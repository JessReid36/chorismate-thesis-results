#!/usr/bin/env python3
# Build the transition-state counterpart of a surrogate reactant calculation.
#
# The surrogate atoms are copied verbatim from the reactant input rather than regenerated. They
# must occupy identical positions in both calculations: the surrogates' internal energy and their
# mutual interaction then cancel exactly in the TS-minus-reactant difference, leaving only their
# interaction with the substrate, which is the quantity of interest. Regenerating them would
# introduce small orientation differences that would not cancel.
#
# The substrate geometry is the QM/MM transition state, not anything derived from the relaxed
# reactant, so the saddle search starts from a structure already known to be a saddle for the
# bare reaction.

import sys

N_SUB = 24
SRC_R = sys.argv[1] if len(sys.argv) > 1 else "surr_ropt.inp"
SRC_TS = sys.argv[2] if len(sys.argv) > 2 else "../08_validate_relaxed/tsopt_charged.inp"
OUT = sys.argv[3] if len(sys.argv) > 3 else "surr_tsopt.inp"


def read_atoms(path, limit=None):
    atoms, started = [], False
    for line in open(path):
        s = line.strip()
        if s.startswith("*") and "xyz" in s:
            started = True
            continue
        if started:
            if s.startswith("*"):
                break
            p = s.split()
            if len(p) == 4:
                atoms.append((p[0], float(p[1]), float(p[2]), float(p[3])))
            if limit and len(atoms) == limit:
                break
    return atoms


sub_ts = read_atoms(SRC_TS, N_SUB)
all_r = read_atoms(SRC_R)
surr = all_r[N_SUB:]

if len(sub_ts) != N_SUB:
    print("read %d TS substrate atoms, expected %d" % (len(sub_ts), N_SUB)); sys.exit(1)
if not surr:
    print("no surrogate atoms found in %s" % SRC_R); sys.exit(1)

n_tot = N_SUB + len(surr)
fh = open(OUT, "w")
fh.write("! B3LYP D3BJ def2-SVP def2/J RIJCOSX CPCM OptTS NumFreq\n")
fh.write("%maxcore 3000\n%pal nprocs 8 end\n")
fh.write("%cpcm epsilon 4.0 end\n")
fh.write("%scf MaxIter 300 end\n")
fh.write("%geom\n  MaxIter 200\n  Calc_Hess true\n  Recalc_Hess 5\n")
fh.write("  Constraints\n    {C %d:%d C}\n  end\nend\n" % (N_SUB, n_tot - 1))
fh.write("* xyz -2 1\n")
for a in sub_ts + surr:
    fh.write("%-2s %16.8f %16.8f %16.8f\n" % (a[0], a[1], a[2], a[3]))
fh.write("*\n")
fh.close()

print("wrote %s" % OUT)
print("  substrate: TS geometry from %s" % SRC_TS)
print("  surrogates: %d atoms copied verbatim from %s" % (len(surr), SRC_R))
print("  frozen: atoms %d-%d" % (N_SUB, n_tot - 1))
print("  total %d atoms, charge -2" % n_tot)
