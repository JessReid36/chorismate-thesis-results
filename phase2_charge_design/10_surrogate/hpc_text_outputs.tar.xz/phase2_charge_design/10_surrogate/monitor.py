#!/usr/bin/env python3
# Status of every relaxed-validation job, across the point-charge and surrogate trees.
#
# The collapse test differs between the two treatments. For point charges any substrate atom
# inside van der Waals contact of a charge is collapse. For surrogates a close contact is
# expected -- an N-H...O salt bridge sits at 1.8-2.2 A, well inside the vdW sum -- so the test is
# the trend instead: sustained approach is collapse, a minimum followed by relaxation outward is
# a salt bridge forming. Far-field references sit ~11 A out and their small jitter is not a trend,
# so they are excluded from the verdict.
#
# A job whose output stops without ORCA's termination line has been killed or has died; that is
# reported separately from one still writing.
#
# Pure Python: numpy on the login node needs the thread environment set, and this is distances.

import math
import os
import time

HARTREE_TO_KCAL = 627.5094740631
N_SUB = 24
BREAK, FORM = (7, 8), (0, 12)
VDW = {"C": 1.70, "N": 1.55, "O": 1.52, "H": 1.20, "S": 1.80}
STALE_MIN = 20                 # output untouched this long, with no termination line, means dead

# frozen references, verified from the committed Stage-1 single points
FROZEN_R, FROZEN_TS = -836.365884, -836.340751
FROZEN_BARRIER = (FROZEN_TS - FROZEN_R) * HARTREE_TO_KCAL
FROZEN_PREDICTION = -10.888    # frozen-density ddE for the K=2 net-neutral design

TREES = [
    ("../08_validate_relaxed", ["ropt_bare", "ropt_charged", "tsopt_bare", "tsopt_charged"], "pc"),
    (".", ["surr_ropt", "surr_ropt_ref", "surr_tsopt", "surr_tsopt_ref"], "surr"),
]
FARFIELD = ("surr_ropt_ref", "surr_tsopt_ref")


def scan_out(path):
    cyc = 0
    energy = None
    conv = term = False
    freqs, in_freq = [], False
    for line in open(path, errors="ignore"):
        if "GEOMETRY OPTIMIZATION CYCLE" in line:
            cyc += 1
        elif "FINAL SINGLE POINT ENERGY" in line:
            try:
                energy = float(line.split()[-1])
            except ValueError:
                pass
        elif "HURRAY" in line or "THE OPTIMIZATION HAS CONVERGED" in line:
            conv = True
        elif "ORCA TERMINATED NORMALLY" in line:
            term = True
        elif "VIBRATIONAL FREQUENCIES" in line:
            in_freq, freqs = True, []
        elif in_freq:
            p = line.split()
            if len(p) >= 2 and p[0].rstrip(":").isdigit():
                try:
                    v = float(p[1])
                except ValueError:
                    continue
                if abs(v) > 1e-6:
                    freqs.append(v)
            elif "NORMAL MODES" in line:
                in_freq = False

    idle = (time.time() - os.path.getmtime(path)) / 60.0
    if term and conv:
        state = "done"
    elif term:
        state = "ended unconv"
    elif idle > STALE_MIN:
        state = "dead %dm" % idle
    else:
        state = "running"
    return state, cyc, energy, [f for f in freqs if f < 0]


def frames(path):
    out, cur = [], []
    for line in open(path, errors="ignore"):
        p = line.split()
        if len(p) == 1 and p[0].isdigit():
            if cur:
                out.append(cur)
            cur = []
            continue
        if len(p) == 4:
            try:
                cur.append((p[0], float(p[1]), float(p[2]), float(p[3])))
            except ValueError:
                pass
    if cur:
        out.append(cur)
    return [f for f in out if len(f) >= N_SUB]


def d(a, b):
    return math.sqrt((a[1]-b[1])**2 + (a[2]-b[2])**2 + (a[3]-b[3])**2)


def contact(frame, kind, pcs):
    sub = frame[:N_SUB]
    others = frame[N_SUB:] if kind == "surr" else [("q", p[1], p[2], p[3]) for p in pcs]
    if not others:
        return None
    best = None
    for s in sub:
        for t in others:
            dd = d(s, t)
            if best is None or dd < best[0]:
                best = (dd, s[0], t[0])
    return best


def read_pc(path):
    out = []
    if not os.path.isfile(path):
        return out
    for line in open(path).read().splitlines()[1:]:
        p = line.split()
        if len(p) == 4:
            out.append((float(p[0]), float(p[1]), float(p[2]), float(p[3])))
    return out


def verdict(trend, kind, stem):
    if len(trend) < 5:
        return ""
    if stem in FARFIELD:
        return "field off, %.1f A" % trend[-1]
    if kind == "surr":
        lo = min(trend)
        if trend[-1] < 1.4:
            return "COLLAPSED"
        if trend[-1] > lo + 0.03:
            return "salt bridge, min %.2f now %.2f" % (lo, trend[-1])
        if trend[-1] < trend[-5] - 0.05:
            return "still approaching"
        return "settled %.2f" % trend[-1]
    if trend[-1] < 1.9:
        return "COLLAPSED"
    return "drifting in" if trend[-1] < trend[0] - 0.3 else "stable"


results = {}
for root, stems, kind in TREES:
    if not os.path.isdir(root):
        continue
    print("=== %s ===" % ("point-charge runs" if kind == "pc" else "surrogate runs"))
    print("%-16s %-13s %5s  %-15s %-10s %-7s %s"
          % ("job", "state", "cyc", "energy", "contact", "form", "note"))
    for stem in stems:
        out = os.path.join(root, stem + ".out")
        if not os.path.isfile(out):
            print("%-16s not started" % stem)
            continue
        state, cyc, energy, imag = scan_out(out)
        results[stem] = (state, energy, imag)
        trj = os.path.join(root, stem + "_trj.xyz")
        cont = fm = note = ""
        if os.path.isfile(trj):
            fr = frames(trj)
            if fr:
                pcs = read_pc(os.path.join(root, "design_charges.pc")) if kind == "pc" else []
                trend = [c[0] for c in (contact(f, kind, pcs) for f in fr) if c]
                c = contact(fr[-1], kind, pcs)
                if c:
                    cont = "%s-%s %.2f" % (c[1], c[2], c[0])
                fm = "%.3f" % d(fr[-1][FORM[0]], fr[-1][FORM[1]])
                note = verdict(trend, kind, stem)
        if imag:
            tag = "1 imag %.0f" % imag[0] if len(imag) == 1 else "%d IMAG %.0f" % (len(imag), imag[0])
            note = tag + ("" if not note else "; " + note)
        if state.startswith("dead"):
            note = "output stopped without terminating" + ("" if not note else "; " + note)
        e = "%.6f" % energy if energy is not None else "-"
        print("%-16s %-13s %5d  %-15s %-10s %-7s %s" % (stem, state, cyc, e, cont, fm, note))
    print("")

print("barriers, within a consistent treatment only:")
pairs = [("bare, 24 atom", "ropt_bare", "tsopt_bare"),
         ("point charge K2", "ropt_charged", "tsopt_charged"),
         ("surrogate field on", "surr_ropt", "surr_tsopt"),
         ("surrogate field off", "surr_ropt_ref", "surr_tsopt_ref")]
bars = {}
for label, r, t in pairs:
    if r not in results or t not in results:
        continue
    sr, er, _ = results[r]
    st, et, imag = results[t]
    if sr != "done" or st != "done" or er is None or et is None:
        continue
    b = (et - er) * HARTREE_TO_KCAL
    bars[label] = b
    warn = "" if len(imag) == 1 else "   [%d imaginary modes, not a clean TS]" % len(imag)
    print("  %-20s %+8.3f kcal/mol%s" % (label, b, warn))

if "bare, 24 atom" in bars:
    print("\n  frozen barrier at the QM/MM geometries was %+.3f" % FROZEN_BARRIER)
    print("  relaxing both endpoints raises it by %+.3f, because the reactant gains 5.07"
          % (bars["bare, 24 atom"] - FROZEN_BARRIER))
    print("  kcal/mol on release while the TS gains only 2.30")

if "surrogate field on" in bars and "surrogate field off" in bars:
    eff = bars["surrogate field on"] - bars["surrogate field off"]
    print("\n  RELAXED CATALYTIC EFFECT  %+8.3f kcal/mol" % eff)
    print("    frozen-density prediction %+8.3f" % FROZEN_PREDICTION)
    print("    difference                %+8.3f" % (eff - FROZEN_PREDICTION))
    print("    enzyme electrostatic contribution is about -9.1")
elif not bars:
    print("  none complete yet")
