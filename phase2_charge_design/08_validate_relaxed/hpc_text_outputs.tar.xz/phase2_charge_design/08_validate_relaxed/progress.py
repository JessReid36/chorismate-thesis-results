#!/usr/bin/env python3
# Status of the relaxed-validation set, read from the ORCA outputs rather than the queue.
#
# Pure Python: numpy on the login node segfaults without the thread environment set, and counting
# lines does not warrant the import.

import os

JOBS = (["ropt_bare", "ropt_charged"]
        + ["ropt_K%d" % k for k in range(2, 9)]
        + ["tsopt_bare", "tsopt_charged"]
        + ["tsopt_K%d" % k for k in range(2, 9)])

HARTREE_TO_KCAL = 627.5094740631


def scan(stem):
    path = stem + ".out"
    if not os.path.isfile(path):
        return {"state": "not started"}
    cycles = 0
    energy = None
    converged = False
    terminated = False
    freqs = []
    in_freq = False
    for line in open(path, errors="ignore"):
        if "GEOMETRY OPTIMIZATION CYCLE" in line:
            cycles += 1
        elif "FINAL SINGLE POINT ENERGY" in line:
            try:
                energy = float(line.split()[-1])
            except ValueError:
                pass
        elif "HURRAY" in line or "THE OPTIMIZATION HAS CONVERGED" in line:
            converged = True
        elif "ORCA TERMINATED NORMALLY" in line:
            terminated = True
        elif "VIBRATIONAL FREQUENCIES" in line:
            in_freq = True
            freqs = []
        elif in_freq:
            p = line.split()
            if len(p) >= 2 and p[0].rstrip(":").isdigit():
                try:
                    v = float(p[1])
                except ValueError:
                    continue
                if abs(v) > 1e-6:
                    freqs.append(v)
            elif "NORMAL MODES" in line:
                in_freq = False

    imag = [f for f in freqs if f < 0]
    if terminated and converged:
        state = "done"
    elif terminated:
        state = "ended unconverged"
    else:
        state = "running"
    return {"state": state, "cycles": cycles, "energy": energy,
            "imag": imag, "nfreq": len(freqs)}


def main():
    print("%-16s %-18s %6s  %-16s  %s" % ("job", "state", "cycles", "last energy", "imaginary modes"))
    res = {}
    for stem in JOBS:
        r = scan(stem)
        res[stem] = r
        if r["state"] == "not started":
            print("%-16s %-18s" % (stem, r["state"]))
            continue
        e = "%.6f" % r["energy"] if r["energy"] is not None else "-"
        im = ""
        if r["nfreq"]:
            im = "%d imag" % len(r["imag"])
            if r["imag"]:
                im += "  " + ", ".join("%.1f" % v for v in r["imag"][:3])
        print("%-16s %-18s %6d  %-16s  %s" % (stem, r["state"], r["cycles"], e, im))

    print("\nbarriers available so far:")
    pairs = [("bare", "ropt_bare", "tsopt_bare"),
             ("K2 concentrated", "ropt_charged", "tsopt_charged")]
    pairs += [("K%d distributed" % k, "ropt_K%d" % k, "tsopt_K%d" % k) for k in range(2, 9)]
    base = None
    for label, rst, tst in pairs:
        er = res.get(rst, {}).get("energy")
        et = res.get(tst, {}).get("energy")
        rd = res.get(rst, {}).get("state") == "done"
        td = res.get(tst, {}).get("state") == "done"
        if er is None or et is None or not (rd and td):
            continue
        b = (et - er) * HARTREE_TO_KCAL
        if label == "bare":
            base = b
        eff = "" if base is None or label == "bare" else "   effect %+7.3f" % (b - base)
        nimag = len(res[tst]["imag"])
        warn = "" if nimag == 1 else "   [%d imaginary modes]" % nimag
        print("  %-18s barrier %+7.3f%s%s" % (label, b, eff, warn))
    if base is None:
        print("  none yet; the bare pair must finish first")


if __name__ == "__main__":
    main()
