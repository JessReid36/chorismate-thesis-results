#!/usr/bin/env python3
# Closest approach between substrate atoms and the designed point charges.
#
# A point charge carries no Pauli repulsion, so an optimiser can drive density onto it without
# limit. Any atom sitting well inside van der Waals contact of a charge means the relaxed
# geometry is an artefact of that singularity rather than a response to the field.

import math
import os
import sys

N_SUB = 24
VDW = {"C": 1.70, "O": 1.52, "N": 1.55, "H": 1.20, "S": 1.80}


def read_xyz(path):
    out = []
    for line in open(path).read().splitlines()[2:]:
        p = line.split()
        if len(p) != 4:
            continue
        try:
            out.append((p[0], float(p[1]), float(p[2]), float(p[3])))
        except ValueError:
            continue
        if len(out) == N_SUB:
            break
    return out


def read_pc(path):
    out = []
    for line in open(path).read().splitlines()[1:]:
        p = line.split()
        if len(p) == 4:
            out.append((float(p[0]), float(p[1]), float(p[2]), float(p[3])))
    return out


def report(geom_path, pc_path):
    if not (os.path.isfile(geom_path) and os.path.isfile(pc_path)):
        print("%-22s missing input" % geom_path)
        return
    atoms = read_xyz(geom_path)
    charges = read_pc(pc_path)
    worst = None
    for el, ax, ay, az in atoms:
        for q, cx, cy, cz in charges:
            d = math.sqrt((ax-cx)**2 + (ay-cy)**2 + (az-cz)**2)
            clear = d - VDW.get(el, 1.7)
            if worst is None or clear < worst[0]:
                worst = (clear, d, el, q)
    clear, d, el, q = worst
    flag = ""
    if clear < 0.0:
        flag = "   COLLAPSED (inside vdW radius)"
    elif clear < 0.8:
        flag = "   close"
    print("%-22s closest %s to q=%+.0f : %.3f A  (%.3f A beyond vdW)%s"
          % (os.path.basename(geom_path), el, q, d, clear, flag))


pairs = [("ropt_bare.xyz", "design_charges.pc"),
         ("ropt_charged.xyz", "design_charges.pc")]
pairs += [("ropt_K%d.xyz" % k, "design_K%d.pc" % k) for k in range(2, 9)]
for g, p in pairs:
    report(g, p)
print("\n(ropt_bare has no charges; it is listed only as the reference separation)")
