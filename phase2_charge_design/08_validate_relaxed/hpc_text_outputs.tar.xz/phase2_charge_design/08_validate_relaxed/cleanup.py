#!/usr/bin/env python3
# Remove artefacts of the sixteen resubmitted jobs, without touching anything that took real
# compute or that we generated deliberately.
#
# Preserved absolutely: ropt_bare.* and ropt_charged.* (11 min and 2h22m of finished work), every
# .inp, every .pc, the PBS scripts and the helper scripts. Removed: outputs of the stems being
# rerun, plus PBS spool files.
#
# Runs as a dry run unless given --delete.

import os
import sys

CLEAN_STEMS = (["ropt_K%d" % k for k in range(2, 9)]
               + ["tsopt_bare", "tsopt_charged"]
               + ["tsopt_K%d" % k for k in range(2, 9)])
PROTECT_STEMS = ["ropt_bare", "ropt_charged"]
KEEP_EXT = (".inp", ".pc", ".pbs", ".py", ".tsv", ".npz", ".md")
SPOOL_PREFIXES = ("p2relax.o", "p2relax.e")

do_delete = "--delete" in sys.argv
here = os.getcwd()

remove, keep = [], []
for f in sorted(os.listdir(here)):
    if not os.path.isfile(f):
        continue
    stem = f.split(".")[0]
    ext = os.path.splitext(f)[1]

    if any(f.startswith(p) for p in SPOOL_PREFIXES):
        remove.append(f)
        continue
    if stem in PROTECT_STEMS or f.startswith(tuple(s + "_trj" for s in PROTECT_STEMS)):
        keep.append(f)
        continue
    if ext in KEEP_EXT:
        keep.append(f)
        continue
    if stem in CLEAN_STEMS or any(f.startswith(s + "_trj") or f.startswith(s + ".")
                                  for s in CLEAN_STEMS):
        remove.append(f)
        continue
    keep.append(f)

print("would remove %d file(s):" % len(remove))
for f in remove:
    print("   %s" % f)
print("\nkeeping %d file(s), including:" % len(keep))
for f in keep:
    if f.endswith((".inp", ".pc")) or f.split(".")[0] in PROTECT_STEMS:
        print("   %s" % f)

if do_delete:
    for f in remove:
        os.remove(f)
    print("\nremoved %d file(s)" % len(remove))
else:
    print("\ndry run; rerun with --delete to remove")
