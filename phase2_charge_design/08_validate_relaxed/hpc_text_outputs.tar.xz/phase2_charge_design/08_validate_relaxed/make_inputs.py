#!/usr/bin/env python3
# Generate the K=2..8 relaxed-validation inputs by substitution into the two inputs that already
# ran to convergence, rather than writing fresh ones. Anything not being varied is inherited
# verbatim, so the only difference between designs is the point-charge file.

import os
import re

TEMPLATES = {"ropt": "ropt_charged.inp", "tsopt": "tsopt_charged.inp"}
K_VALUES = range(2, 9)
PC_LINE = re.compile(r'(%\s*pointcharges\s+")([^"]+)(")', re.I)


def check_pc(path):
    lines = [l for l in open(path).read().splitlines() if l.strip()]
    n = int(lines[0].split()[0])
    body = lines[1:]
    if len(body) != n:
        return "header says %d, file has %d rows" % (n, len(body))
    for row in body:
        q = float(row.split()[0])
        if abs(abs(q) - 1.0) > 1e-6:
            return "non-unit charge %s" % q
    return None


for stem, tmpl in TEMPLATES.items():
    if not os.path.isfile(tmpl):
        print("%-8s template %s missing" % (stem, tmpl))
        continue
    text = open(tmpl).read()
    if not PC_LINE.search(text):
        print("%-8s no %%pointcharges line in %s; not editing blind" % (stem, tmpl))
        continue
    for K in K_VALUES:
        pc = "design_K%d.pc" % K
        if not os.path.isfile(pc):
            print("%-8s K=%d  %s missing" % (stem, K, pc))
            continue
        bad = check_pc(pc)
        if bad:
            print("%-8s K=%d  %s rejected: %s" % (stem, K, pc, bad))
            continue
        out = "%s_K%d.inp" % (stem, K)
        open(out, "w").write(PC_LINE.sub(lambda m: m.group(1) + pc + m.group(3), text))
        print("%-8s K=%d  -> %s  (%s)" % (stem, K, out, pc))

print("\ntemplate pointcharges lines:")
for stem, tmpl in TEMPLATES.items():
    if os.path.isfile(tmpl):
        m = PC_LINE.search(open(tmpl).read())
        print("  %-8s %s" % (stem, m.group(0) if m else "none"))
