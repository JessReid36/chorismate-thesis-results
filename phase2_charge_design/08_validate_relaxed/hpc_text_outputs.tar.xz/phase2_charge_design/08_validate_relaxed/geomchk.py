#!/usr/bin/env python3
# Reacting-coordinate check on the relaxed reactants. Pure Python: numpy on the login node needs
# the thread env vars set and segfaults without them, and two distances do not warrant the import.
import math
import sys

BREAK = (7, 8)      # ether O3 - C4, bond being broken
FORM = (0, 12)      # C1 - C6, bond being formed
REF = {"break": 1.478, "form": 3.181}      # committed reactant geometry
N_SUBSTRATE = 24


def coords(path):
    atoms = []
    for line in open(path).read().splitlines()[2:]:
        p = line.split()
        if len(p) != 4:
            continue
        try:
            atoms.append((float(p[1]), float(p[2]), float(p[3])))
        except ValueError:
            continue
        if len(atoms) == N_SUBSTRATE:
            break
    return atoms


def dist(a, i, j):
    dx = a[i][0] - a[j][0]
    dy = a[i][1] - a[j][1]
    dz = a[i][2] - a[j][2]
    return math.sqrt(dx * dx + dy * dy + dz * dz)


for path in sys.argv[1:]:
    try:
        a = coords(path)
    except IOError:
        print("%-20s not found" % path)
        continue
    if len(a) < N_SUBSTRATE:
        print("%-20s only %d atoms parsed" % (path, len(a)))
        continue
    b = dist(a, BREAK[0], BREAK[1])
    f = dist(a, FORM[0], FORM[1])
    print("%-20s break %.3f (%+.3f)   form %.3f (%+.3f)"
          % (path, b, b - REF["break"], f, f - REF["form"]))
print("reference reactant   break %.3f            form %.3f" % (REF["break"], REF["form"]))
