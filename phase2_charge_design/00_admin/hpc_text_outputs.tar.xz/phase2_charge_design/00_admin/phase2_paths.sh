# Phase 2 canonical paths - source at the top of every Phase 2 script.
# Changing the reaction (placeholder -> final Phase 1 NEB triple) = overwrite the
# three files in $SUBSTRATE_DIR and re-run. No downstream script hard-codes a geometry path.
export PHASE2_ROOT="/home/18660916/system_development/phase2_charge_design"
export SUBSTRATE_DIR="/home/18660916/system_development/phase2_charge_design/01_substrate"

# Fixed filename contract for reactant/TS/product (the swap point).
export SUBSTRATE_REACTANT="reactant.xyz"
export SUBSTRATE_TS="ts.xyz"
export SUBSTRATE_PRODUCT="product.xyz"

# Chorismate dianion, closed shell.
export SUBSTRATE_CHARGE="-2"
export SUBSTRATE_MULT="1"
