# Phase 2 layout - charge-design pipeline

Root: `/home/18660916/system_development/phase2_charge_design` (sibling of phase1_system_dev)

## Swap point
`01_substrate/` holds the reactant/TS/product geometries - the only reaction-specific
input. Paths and filenames are defined once in `00_admin/phase2_paths.sh`, sourced by every
downstream script. Finalising Phase 1 = overwrite the three .xyz files and re-run; no code edits.

## Stage directories
00_admin - paths file, layout, per-step audits, checksums, method notes
01_substrate - SWAP POINT: reactant.xyz / ts.xyz / product.xyz + substrate_metadata.tsv
02_baseline - field-free single-points; delta-E-doubledagger and delta-E-rxn reference
03_dvpot - Dv engine: R/TS wavefunctions, orca_vpot ESP, Dv on points
04_grid - SDF, marching-cubes shells, area-proportional sampling, Poisson-disk thinning
05_select - LP/QP, L1 path, MIQP, greedy; selected charges + certificates
06_polarize - predictor-corrector self-consistent QM through the ORCAFF bridge
07_polish - off-grid position refinement
08_validate - whole-path, TS-selectivity, Dmu projection, enzyme overlay, FEP
09_benchmark - GA (GOCAT) comparison
local_workstation - grid + solver steps run on the Ubuntu PC (stages 04, 05)

All placeholder-derived results carry [placeholder-geometry] until the final Phase 1 triple is swapped in.
