#!/usr/bin/env python3
# Re-derive the load-bearing Phase 2 numbers directly from committed ORCA outputs.
#
# Three numbers are currently carried from a prose summary rather than from a file, and all three
# are load-bearing: the bare barrier (which sets the implied-barrier filter that decides which
# designs are reportable), the two polarisation corrections (quoted throughout the write-ups), and
# the theory line of the two Stage-1 single points (their subtraction is only valid if identical).
#
# Nothing here recomputes anything. It reads what is on disk and reports it.

import os
import re
import time

HARTREE_TO_KCAL = 627.5094740631
ROOT = os.path.expanduser("~/system_development/phase2_charge_design")

SUMMARY_BARRIER = 15.771          # value in current use, to be confirmed or replaced
SUMMARY_E_R = -836.365884
SUMMARY_E_TS = -836.340751


def find(name, subdirs):
    for d in subdirs:
        p = os.path.join(ROOT, d, name)
        if os.path.isfile(p):
            return p
    return None


def final_spe(path):
    # ORCA writes one such line per single point; the last is the converged result
    val = None
    for line in open(path, errors="ignore"):
        if "FINAL SINGLE POINT ENERGY" in line:
            try:
                val = float(line.split()[-1])
            except ValueError:
                pass
    return val


def scf_ok(path):
    txt = open(path, errors="ignore").read()
    converged = "SCF CONVERGED AFTER" in txt or "SUCCESS" in txt
    aborted = "ORCA finished by error" in txt or "ABORTING THE RUN" in txt
    return converged and not aborted


def theory_line(path):
    for line in open(path, errors="ignore"):
        s = line.strip()
        if s.startswith("!"):
            return s
    return None


def charge_mult(path):
    for line in open(path, errors="ignore"):
        s = line.strip()
        if s.startswith("*") and len(s.split()) >= 3:
            return " ".join(s.split()[:3])
    return None


def report_sp(label, out_path, inp_path):
    print("%s" % label)
    if out_path is None:
        print("  output not found")
        return None
    print("  file      %s" % out_path)
    print("  mtime     %s" % time.ctime(os.path.getmtime(out_path)))
    print("  converged %s" % scf_ok(out_path))
    e = final_spe(out_path)
    print("  energy    %s Ha" % ("%.6f" % e if e is not None else "not parsed"))
    if inp_path:
        print("  theory    %s" % theory_line(inp_path))
        print("  charge    %s" % charge_mult(inp_path))
    return e


def main():
    print("root %s\n" % ROOT)

    dv = ["03_dvpot"]
    e_r = report_sp("reactant single point",
                    find("sp_reactant.out", dv), find("sp_reactant.inp", dv))
    print("")
    e_ts = report_sp("TS single point",
                     find("sp_ts.out", dv), find("sp_ts.inp", dv))

    print("\nbare barrier")
    if e_r is not None and e_ts is not None:
        barrier = (e_ts - e_r) * HARTREE_TO_KCAL
        print("  from files    E_R %.6f   E_TS %.6f   barrier %+.3f kcal/mol" % (e_r, e_ts, barrier))
        print("  in use        E_R %.6f   E_TS %.6f   barrier %+.3f kcal/mol"
              % (SUMMARY_E_R, SUMMARY_E_TS, SUMMARY_BARRIER))
        d = barrier - SUMMARY_BARRIER
        print("  agreement     %+.4f kcal/mol %s"
              % (d, "(confirmed)" if abs(d) < 0.01 else "(DIFFERS - the filter must be redone)"))
    else:
        print("  cannot verify; one or both energies unavailable")

    print("\npolarisation stage")
    pol_dir = os.path.join(ROOT, "06_polarize")
    if not os.path.isdir(pol_dir):
        print("  06_polarize not present")
    else:
        entries = sorted(os.listdir(pol_dir))
        print("  %d entries: %s" % (len(entries), ", ".join(entries[:12])))
        for f in entries:
            p = os.path.join(pol_dir, f)
            if not os.path.isfile(p) or os.path.getsize(p) > 5000000:
                continue
            if f.endswith((".out", ".txt", ".tsv", ".md", ".log")):
                hits = []
                for line in open(p, errors="ignore"):
                    if re.search(r"-1[0-9]\.[0-9]{2}|polariz|ddE|kcal", line, re.I):
                        hits.append(line.rstrip())
                if hits:
                    print("  --- %s" % f)
                    for h in hits[:8]:
                        print("      %s" % h)

    print("\nrelaxed validation stage")
    rel_dir = os.path.join(ROOT, "08_validate_relaxed")
    if not os.path.isdir(rel_dir):
        print("  08_validate_relaxed not present")
        return
    for f in sorted(os.listdir(rel_dir)):
        p = os.path.join(rel_dir, f)
        if not os.path.isfile(p):
            continue
        size = os.path.getsize(p)
        note = ""
        if f.endswith(".out"):
            e = final_spe(p)
            done = "HURRAY" in open(p, errors="ignore").read()
            note = "  last SPE %s  optimisation converged %s" % (
                ("%.6f" % e if e is not None else "none"), done)
        print("  %-28s %8d bytes%s" % (f, size, note))


if __name__ == "__main__":
    main()
