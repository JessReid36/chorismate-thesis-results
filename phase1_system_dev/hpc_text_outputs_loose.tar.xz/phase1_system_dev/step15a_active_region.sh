#!/usr/bin/env bash
# Step 15a - define the QM/MM active (free) region for the reaction path: every residue
# with any atom within R_free of the CHA#2 substrate is free; everything else frozen.
# Residue-based (never split), min-image. Written ONCE here and reused for the reactant
# opt, product state, and all NEB-TS images (active region must be identical along a path).
set -euo pipefail
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
R_FREE="${1:-12.0}"
root="$HOME/system_development"
prmtop="$root/03_amber/tleap_build/complex_solvated.prmtop"
rst="$root/05_qmmm/12_frame_selection/frames/frame_00820_CHA2.rst7"
outdir="$root/05_qmmm/15_active_region"; mkdir -p "$outdir"
out="$outdir/active_atoms_R${R_FREE%.*}.txt"
for f in "$prmtop" "$rst"; do [[ -s "$f" ]] || { echo "FAIL missing $f"; exit 1; }; done

python3 - "$prmtop" "$rst" 383 "$R_FREE" "$out" <<'PY'
import sys, os, re
import numpy as np
os.environ.setdefault("OPENBLAS_NUM_THREADS","1")
prmtop, rst7, sub_resid, Rfree, out = sys.argv[1], sys.argv[2], int(sys.argv[3]), float(sys.argv[4]), sys.argv[5]
def parse_prmtop(path):
    flags,fmts,cur={},{},None
    for ln in open(path,errors="replace"):
        ln=ln.rstrip("\n")
        if ln.startswith("%FLAG"): cur=ln.split()[1]; flags[cur]=[]
        elif ln.startswith("%FORMAT"): fmts[cur]=ln[ln.find("(")+1:ln.rfind(")")]
        elif ln.startswith("%"): continue
        elif cur is not None: flags[cur].append(ln)
    def width(f):
        m=re.match(r"\s*\d*[aAiIeEfFgG](\d+)",f); return int(m.group(1)) if m else None
    def toks(name,cast):
        w=width(fmts.get(name,"")); out=[]
        for ln in flags.get(name,[]):
            if w: out+=[ln[i:i+w].strip() for i in range(0,len(ln.rstrip()),w) if ln[i:i+w].strip()]
            else: out+=ln.split()
        return [cast(x) for x in out]
    return toks("POINTERS",int)[0],toks("ATOM_NAME",str),toks("RESIDUE_LABEL",str),toks("RESIDUE_POINTER",int)
natom,names,labels,resptr=parse_prmtop(prmtop)
nres=len(labels); starts=[p-1 for p in resptr]+[natom]
lines=open(rst7).read().splitlines(); nat=int(lines[1].split()[0]); vals=[]
for ln in lines[2:]:
    if len(vals)>=nat*3: break
    vals+=[float(ln[i:i+12]) for i in range(0,len(ln.rstrip()),12)]
xyz=np.array(vals[:nat*3]).reshape(nat,3)
box=np.array([float(lines[-1][i:i+12]) for i in range(0,36,12)])
sub=list(range(starts[sub_resid-1],starts[sub_resid])); subxyz=xyz[sub]
free_res=[]
for ri in range(nres):
    a0,a1=starts[ri],starts[ri+1]
    d=xyz[a0:a1][:,None,:]-subxyz[None,:,:]; d-=np.round(d/box)*box
    if np.sqrt((d*d).sum(2)).min()<Rfree: free_res.append(ri)
active=[a for ri in free_res for a in range(starts[ri],starts[ri+1])]  # 0-based
open(out,"w").write(" ".join(map(str,active))+"\n")
from collections import Counter
byname=Counter(labels[ri] for ri in free_res)
waters=sum(v for k,v in byname.items() if k in ("WAT","HOH"))
prot=len(free_res)-waters-sum(v for k,v in byname.items() if k in ("Na+","Cl-"))
# active-site residues we expect free (inter-subunit; global numbering): Arg90 partners etc.
key=[217,90,344,7,63,78,205,332,261,108,115]  # a superset incl CHA#2's Arg90(217)/Glu78(205)
present=[k for k in key if (k-1) in free_res]
print("STEP 15a - active region  R_free=%.1f A  substrate=CHA res %d"%(Rfree,sub_resid))
print("  free residues: %d  (protein ~%d, water ~%d)"%(len(free_res),prot,waters))
print("  active atoms (incl 24 QM): %d  -> frozen: %d"%(len(active),natom-len(active)))
print("  substrate in free set: %s"%((sub_resid-1) in free_res))
print("  key active-site residues present (global#): %s"%present)
print("  wrote", out)
PY
echo "STEP 15a DONE"

