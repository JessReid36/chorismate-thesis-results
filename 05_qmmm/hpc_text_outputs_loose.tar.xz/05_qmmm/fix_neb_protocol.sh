#!/usr/bin/env bash
# fix_neb_protocol.sh - bring the ensemble NEB stage onto the reference protocol.
#
# WHAT WENT WRONG
#   Frame 820's reference path was computed with NEB-TS and a transition-state
#   guess supplied as TS_PDBFile. The ensemble's neb.inp was written from scratch
#   by step19a_ensemble_prepare.sh rather than derived from that reference, and
#   two directives were dropped: the method became NEB-CI, and no TS guess was
#   given. Every other directive is byte-identical, and all fourteen frames agree
#   with one another, so this is one omission rather than a systematic drift.
#
#   The consequence is visible in the output. Frame 820's band has a first
#   segment of 0.642 A and a total path of 5.26 A. The ensemble bands, started
#   from a straight-line interpolation with no guess, have first segments of 1.85
#   to 3.67 A and total paths of 5.4 to 12.9 A, and their early images relax as
#   much as 13.9 kcal/mol BELOW the converged reactant. A barrier measured from
#   image 0 against a band that has fallen off the reactant basin is not
#   comparable to the reference, and the reported spread of 4.48 to 24.65
#   kcal/mol reflects that rather than conformational variation.
#
# THE FIX
#   The transition-state guess for frame 820 is win_11.pdb, the highest-energy
#   window of its restrained scan, at -1076.102940 Eh. Every ensemble frame has
#   its own scan with the same twenty windows and its own scan_energies.tsv, so
#   the equivalent guess exists for each and only needs staging.
#
#   This script stages that window as tsguess.pdb, switches the method to NEB-TS,
#   and adds the TS_PDBFile directive, so that the ensemble and the reference run
#   the same protocol.
#
# WHAT IS NOT TOUCHED
#   Reactant optimisations, scans and product optimisations are all sound and all
#   verified identical in protocol to the reference. Nothing before the NEB stage
#   is repeated.
#
# Usage:
#   bash fix_neb_protocol.sh            report only, changes nothing
#   bash fix_neb_protocol.sh --apply    stage guesses and rewrite neb.inp

set -uo pipefail
ENS="$HOME/system_development/05_qmmm/19_ensemble"
REF="$HOME/system_development/05_qmmm/18_nebts/nebts.inp"
APPLY=0
[[ "${1:-}" == "--apply" ]] && APPLY=1

[[ -f "$REF" ]] || { echo "FAIL: reference input not found at $REF"; exit 1; }

echo "reference protocol, from 18_nebts/nebts.inp:"
grep -E "^!|TS_PDBFile|Product_PDBFile|NImages|Interpolation" "$REF" | sed 's/^/    /'
echo

printf "%-8s %-8s %-12s %-14s %s\n" frame peak "E(peak)/Eh" "window file" action
printf -- "------------------------------------------------------------------------\n"

for d in "$ENS"/frame_*; do
  fr=$(basename "$d")
  se="$d/scan/scan_energies.tsv"
  [[ -s "$se" ]] || { printf "%-8s %s\n" "${fr#frame_}" "no scan_energies.tsv"; continue; }

  # highest-energy window: columns are window, r, E
  read -r w e < <(sort -t$'\t' -k3 -g "$se" | tail -1 | awk -F'\t' '{print $1, $3}')
  win="$d/scan/win_${w}.pdb"
  if [[ ! -s "$win" ]]; then
    printf "%-8s %-8s %-12s %-14s %s\n" "${fr#frame_}" "$w" "$e" "missing" "SKIP"
    continue
  fi

  if [[ $APPLY -eq 0 ]]; then
    printf "%-8s %-8s %-12s %-14s %s\n" "${fr#frame_}" "$w" "$e" "win_${w}.pdb" "would stage"
    continue
  fi

  cp "$win" "$d/tsguess.pdb"
  cp "$d/neb.inp" "$d/neb.inp.neb_ci_superseded"
  # method keyword, and the TS guess inside the %neb block
  sed -i 's/ NEB-CI / NEB-TS /' "$d/neb.inp"
  grep -q 'TS_PDBFile' "$d/neb.inp" || \
    sed -i '/Product_PDBFile/a\  TS_PDBFile "tsguess.pdb"' "$d/neb.inp"
  ok=$(diff <(grep -vE "^ *[0-9]|pdbfile|PDBFile" "$d/neb.inp") \
            <(grep -vE "^ *[0-9]|pdbfile|PDBFile" "$REF") >/dev/null && echo match || echo DIFFERS)
  printf "%-8s %-8s %-12s %-14s %s\n" "${fr#frame_}" "$w" "$e" "win_${w}.pdb" "staged, protocol $ok"
done

echo
if [[ $APPLY -eq 0 ]]; then
  echo "REPORT ONLY. Re-run with --apply to stage the guesses and rewrite neb.inp."
else
  echo "Every frame should read 'protocol match' above: the directive lines now"
  echo "agree with the reference on everything but filenames."
  echo
  echo "The superseded inputs are kept as neb.inp.neb_ci_superseded."
  echo
  echo "Resubmit with:"
  echo "  cd $HOME/system_development/05_qmmm"
  echo "  for f in \$(ls -d 19_ensemble/frame_* | sed 's/.*frame_//'); do"
  echo "    qsub 19_ensemble/frame_\$f/neb.pbs"
  echo "  done"
fi
