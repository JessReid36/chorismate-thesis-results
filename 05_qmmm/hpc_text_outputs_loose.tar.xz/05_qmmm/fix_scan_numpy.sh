#!/usr/bin/env bash
# fix_scan_numpy.sh - remove the numpy dependency from the scan window driver.
#
# THE FAILURE
# -----------
# run_scan.sh extracts win_NN.pdb from each window's trajectory with an inline
# python3 block that begins "import sys, numpy as np". Some compute nodes have
# a python3 with numpy and some do not: comp049 does, comp045 does not. On a
# node without it the extraction dies with ModuleNotFoundError, no win_NN.pdb is
# written, and the next window fails with CANNOT OPEN FILE. The driver then
# reports "NO TRAJ" and exits with status 0, so the failure is silent.
#
# Frames 09025, 10775 and 19185 all failed this way. Frames 05680, 07310, 12485,
# 14155 and 17505 are running on nodes that happen to have numpy.
#
# THE FIX
# -------
# numpy is used for two things only: building a 3-vector and taking its norm.
# Both are replaced with math.sqrt on the coordinate tuples already in hand.
# Nothing else in the block needs it. This removes the node dependency rather
# than trying to guarantee a module is present everywhere.
#
# Usage
#   bash fix_scan_numpy.sh                 # report which files need patching
#   bash fix_scan_numpy.sh --apply         # patch them
#
# Safe on running jobs: the loop reads run_scan.sh once at start, and bash has
# already read past the python block for any window in progress. Even so, this
# only patches frames with no live scan, listed in SKIP below.

set -uo pipefail
ENS="$HOME/system_development/05_qmmm/19_ensemble"
APPLY=0
[[ "${1:-}" == "--apply" ]] && APPLY=1

# frames with a scan currently running - do not touch
SKIP="$(qstat -f -u "$USER" 2>/dev/null | grep -A1 "Job_Name = cm19_s" \
        | grep -o "cm19_s[0-9]*" | sed 's/cm19_s//' || true)"
echo "scans currently running (will be skipped): ${SKIP:-none}"
echo

for rs in "$ENS"/frame_*/scan/run_scan.sh; do
  [[ -f "$rs" ]] || continue
  fr="$(basename "$(dirname "$(dirname "$rs")")" | sed 's/frame_0*//')"
  if grep -qx "$fr" <<< "$SKIP"; then
    echo "  frame $fr: scan running, skipped"
    continue
  fi
  if ! grep -q "import sys, numpy as np" "$rs"; then
    echo "  frame $fr: already patched or different format"
    continue
  fi
  if [[ $APPLY -eq 0 ]]; then
    echo "  frame $fr: WOULD PATCH"
    continue
  fi

  python3 - "$rs" <<'PY'
import sys
p = sys.argv[1]
t = open(p).read()

old_imp = "import sys, numpy as np"
new_imp = "import sys, math"
assert old_imp in t, "import line not found"
t = t.replace(old_imp, new_imp)

old_calc = """xyz=lambda i: np.array(coords[i])
brk=np.linalg.norm(xyz(6215)-xyz(6214)); frm=np.linalg.norm(xyz(6219)-xyz(6207))"""
new_calc = """def sep(i, j):
    a, b = coords[i], coords[j]
    return math.sqrt(sum((a[k]-b[k])**2 for k in range(3)))
brk = sep(6215, 6214); frm = sep(6219, 6207)"""
assert old_calc in t, "distance block not found"
t = t.replace(old_calc, new_calc)

assert "np." not in t, "a numpy reference remains"
open(p, "w").write(t)
print("    patched")
PY
done

echo
if [[ $APPLY -eq 0 ]]; then
  echo "REPORT ONLY. Re-run with --apply to patch."
else
  echo "Patched. Verify with:"
  echo "  grep -l numpy $ENS/frame_*/scan/run_scan.sh"
  echo "(no output means every non-running scan is clean)"
fi
