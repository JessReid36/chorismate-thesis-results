#!/usr/bin/env python3
"""
check1_mm_field.py - does the environment's electrostatic field explain the
frame-to-frame variation in the quantum reaction energy?

WHY THIS IS THE FIRST CHECK
    The quantum part of the reaction energy varies from 5.10 to 19.68 kcal/mol
    across the ensemble, a range of 14.6, although the same twenty-four atoms
    undergo the same rearrangement in every frame and every product was verified
    genuine. Under electrostatic embedding the quantum energy includes the
    interaction of the quantum density with the surrounding point charges, so a
    spread of that size says the field those charges impose differs between
    frames. This measures that field directly.

WHAT IS COMPUTED
    For each frame, the electrostatic potential the molecular-mechanical
    environment exerts at each of the twenty-four quantum atoms, as a direct
    Coulomb sum over every classical charge in the system:

        V(r) = sum over MM atoms of q_i / |r - r_i|

    The quantum atoms are excluded from the sum, since they are not classical
    charges in the calculation. Charges are read from the ORCAFF parameter file,
    which is the same file the QM/MM calculation itself uses, so this is the
    field ORCA saw and not a reconstruction of it.

    Two summaries are reported per frame. The mean potential over the
    twenty-four atoms describes the overall electrostatic environment. The
    difference between the potential at the atoms that gain electron density
    during the reaction and those that lose it is the quantity that should
    couple to the reaction energy, and is the environment-side analogue of the
    difference potential used in the design work.

NO PERIODIC IMAGES
    The sum is over the primary cell as ORCA treats it. This matches the QM/MM
    calculation rather than the molecular dynamics, which used particle-mesh
    Ewald.

Usage:  python3 check1_mm_field.py
Standard library only; safe on the login node.
"""
import math
import os
import re

ROOT = os.path.expanduser("~/system_development/05_qmmm")
FRAMES = "02450 04085 05680 07310 08170 09025 09900 10775 11630 12485 14155 15825 17505 19185".split()
QM0, QM1 = 6207, 6231           # zero-based, inclusive-exclusive
BOHR = 0.529177210903
HARTREE = 627.5094740631

# Within the 24-atom quantum block, the atoms whose environment matters most.
# The ether oxygen O3 accumulates negative charge as the C4-O3 bond breaks; the
# forming-bond carbons C1 and C6 are where density is instead depleted.
I_O3, I_C4, I_C1, I_C6 = 7, 8, 0, 12


def read_charges(path):
    """Charges from an ORCAFF parameter file.

    The file is sectioned. After a line containing "$atoms" comes a count line
    giving the number of atoms, then exactly that many atom lines of the form

        index element charge -epsilon Rmin -epsilon/2 Rmin(1-4)

    followed by "$bonds" and the bonded terms. The atom block must therefore be
    read by count rather than by line shape: the bonded sections also begin with
    an integer and would otherwise be mistaken for atoms, which is what produced
    150741 "charges" for a 55680-atom system.
    """
    lines = open(path, errors="replace").read().splitlines()
    i = next((k for k, l in enumerate(lines) if l.strip() == "$atoms"), None)
    if i is None:
        raise ValueError(f"{path}: no $atoms section")
    n = int(lines[i + 1].split()[0])
    q = []
    for l in lines[i + 2: i + 2 + n]:
        q.append(float(l.split()[2]))
    if len(q) != n:
        raise ValueError(f"{path}: expected {n} atoms, read {len(q)}")
    return q


def read_xyz_pdb(path):
    out = []
    for l in open(path, errors="replace"):
        if l.startswith(("ATOM", "HETATM")):
            out.append((float(l[30:38]), float(l[38:46]), float(l[46:54])))
    return out


def mm_potential_at(points, coords, charges, skip):
    """Potential in atomic units at each point, from every charge except those
    whose index is in skip."""
    out = []
    for p in points:
        v = 0.0
        px, py, pz = p
        for i, (cx, cy, cz) in enumerate(coords):
            if i in skip:
                continue
            dx = px - cx; dy = py - cy; dz = pz - cz
            r = math.sqrt(dx*dx + dy*dy + dz*dz)
            if r > 1e-6:
                v += charges[i] / r
        out.append(v * BOHR)     # e/Angstrom -> atomic units
    return out


def qm_energy(path):
    for l in reversed(open(path, errors="replace").read().splitlines()):
        m = re.match(r"\s*FINAL SINGLE POINT ENERGY\s+(-?\d+\.\d+)\s*$", l)
        if m:
            return float(m.group(1))
    return None


def main():
    skip = set(range(QM0, QM1))
    print(f"{'frame':<8}{'dE(QM)':>9}{'V mean R':>11}{'V mean P':>11}"
          f"{'dV(O3-C1) R':>13}{'dV(O3-C1) P':>13}")
    print("-" * 66)
    rows = []
    for f in FRAMES:
        d = f"{ROOT}/19_ensemble/frame_{f}"
        prms = f"{d}/complex_solvated.ORCAFF.prms"
        if not os.path.exists(prms):
            print(f"{f:<8} no ORCAFF file"); continue
        charges = read_charges(prms)
        vals = {}
        for state in ("reactant_opt", "product_opt"):
            pdb = f"{d}/{state}.pdb"
            if not os.path.exists(pdb):
                vals = None; break
            coords = read_xyz_pdb(pdb)
            if len(coords) != len(charges):
                print(f"{f:<8} atom/charge mismatch: {len(coords)} vs {len(charges)}")
                vals = None; break
            qm = coords[QM0:QM1]
            v = mm_potential_at(qm, coords, charges, skip)
            vals[state] = v
        if not vals:
            continue
        er = qm_energy(f"{d}/reactant_opt.out")
        ep = qm_energy(f"{d}/product_opt.out")
        dqm = (er - ep) * HARTREE if (er and ep) else float("nan")
        vr, vp = vals["reactant_opt"], vals["product_opt"]
        mr = sum(vr) / len(vr); mp = sum(vp) / len(vp)
        dr = vr[I_O3] - vr[I_C1]
        dp = vp[I_O3] - vp[I_C1]
        rows.append((f, dqm, mr, mp, dr, dp))
        print(f"{f:<8}{dqm:>9.2f}{mr:>11.5f}{mp:>11.5f}{dr:>13.5f}{dp:>13.5f}")

    if len(rows) < 6:
        print("\ntoo few frames to correlate")
        return

    def pear(x, y):
        n = len(x); mx = sum(x)/n; my = sum(y)/n
        sxx = sum((a-mx)**2 for a in x); syy = sum((b-my)**2 for b in y)
        if sxx == 0 or syy == 0: return float("nan")
        return sum((a-mx)*(b-my) for a, b in zip(x, y)) / math.sqrt(sxx*syy)

    dqm = [r[1] for r in rows]
    print("\n" + "=" * 66)
    print("Correlation of the quantum reaction energy with the environment field")
    print("=" * 66)
    for lbl, idx in (("mean potential at the substrate, reactant", 2),
                     ("mean potential at the substrate, product", 3),
                     ("potential difference O3 minus C1, reactant", 4),
                     ("potential difference O3 minus C1, product", 5)):
        print(f"  {lbl:<44} r = {pear([r[idx] for r in rows], dqm):+.3f}")
    ch = [r[3]-r[2] for r in rows]
    print(f"  {'change in mean potential, reactant to product':<44} r = {pear(ch, dqm):+.3f}")
    print()
    print("  A strong correlation would mean the frame-to-frame variation in the")
    print("  quantum reaction energy is driven by the field the environment")
    print("  imposes, which is both the explanation for the spread and a direct")
    print("  demonstration of the premise the design work rests on. A weak one")
    print("  means the cause lies elsewhere and the remaining checks are needed.")


if __name__ == "__main__":
    main()
