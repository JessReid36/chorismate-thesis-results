#!/usr/bin/env bash
# patch_step19c_v2.sh - have the scan stage produce the transition-state guess.
#
# WHY
#   The band calculation needs a guess at the saddle as well as the two
#   endpoints. The scan produces it: its highest-energy window is where the
#   reference calculation's tsguess.pdb came from, being byte-identical to
#   win_11.pdb of the reference scan, whose window 11 is the energy maximum.
#
#   Until now this was done by hand for the reference and not at all for the
#   ensemble, which is why the ensemble's band inputs named no guess.
#
# HOW
#   stage_tsguess.sh is copied into each frame's scan directory alongside
#   run_scan.sh, and the generated job calls it after the scan completes. This
#   follows the pattern already used for the scan driver: one definition, copied,
#   rather than one written per job. The stage that copies did not drift between
#   the reference and the ensemble; the stage that wrote its input from scratch
#   did.
#
# PREREQUISITE
#   stage_tsguess.sh must be present in 16_scan/ alongside run_scan.sh.

set -euo pipefail
[[ -f step19c_scan_product.sh ]] || { echo "run from the directory holding step19c_scan_product.sh"; exit 1; }
[[ -f 16_scan/stage_tsguess.sh ]] || { echo "FAIL: 16_scan/stage_tsguess.sh not found"; exit 1; }
cp step19c_scan_product.sh step19c_scan_product.sh.bak2
echo "backup: step19c_scan_product.sh.bak2"

python3 - <<'PY'
from pathlib import Path
p = Path("step19c_scan_product.sh")
t = p.read_text()

# 1. copy the staging script into the frame's scan directory, next to wherever
#    run_scan.sh is copied
import re
m = re.search(r'^(\s*)cp\s+"\$ref/run_scan\.sh"\s+"(\$\w+)/run_scan\.sh".*$',
              t, re.M)
if m:
    line, indent, dest = m.group(0), m.group(1), m.group(2)
    t = t.replace(line, line + "\n" + indent +
                  'cp "$ref/stage_tsguess.sh" "%s/stage_tsguess.sh"' % dest, 1)
    print("  staging script will be copied to %s alongside run_scan.sh" % dest)
else:
    raise SystemExit("could not find where run_scan.sh is copied; "
                     "paste that line and the patch will be adjusted")

# 2. call it from the generated job, after the scan-complete check
anchor = """    echo 'tail -3 scan_progress.tsv 2>/dev/null'"""
addition = """    echo 'bash stage_tsguess.sh || exit 1'
    echo 'tail -3 scan_progress.tsv 2>/dev/null'"""
if anchor not in t:
    raise SystemExit("could not find the scan job tail")
t = t.replace(anchor, addition, 1)
print("  generated job will call it after the scan completes")

p.write_text(t)
PY

bash -n step19c_scan_product.sh && echo "generator syntax OK"
echo
echo "Now regenerate one frame and check the JOB it writes is valid,"
echo "not only the generator:"
echo "  bash step19c_scan_product.sh 11630 >/dev/null 2>&1"
echo "  bash -n 19_ensemble/frame_11630/scan.pbs && echo 'generated job is valid'"
echo "  grep -n stage_tsguess 19_ensemble/frame_11630/scan.pbs"
