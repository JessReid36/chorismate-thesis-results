#!/usr/bin/env python3
"""
sampling_quality.py - how many statistically independent configurations does this
trajectory contain?

WHY THIS EXISTS
    The correlation time measured from the backbone deviation against a fixed
    reference gave 699 ps or 2349 ps depending on the reference chosen, a
    disagreement of 3.4-fold that would put the number of independent
    configurations anywhere between 10 and 35.

    Grossfield et al. (2018) show why neither is meaningful. The correlation time
    is defined for a stationary series, "meaning that tau is independent of t",
    and Chodera (2016) states the same precondition for the statistical
    inefficiency: the analysis applies "in a stationary timeseries free of bias".
    A series whose mean is still rising satisfies neither. The same guide notes
    that the deviation against a single reference "should really be considered as
    another equilibration test" and "is not even a particularly good test of
    equilibration", because "the degeneracy of RMSD means you cannot tell if the
    simulation is exploring new states that are equidistant from the chosen
    reference".

    Their recommendation is to compare "auto-correlation times for individual
    observables". This does that, on observables that fluctuate about a mean
    rather than drifting, and that are the ones the barrier depends on.

WHAT IT COMPUTES

    1. The integrated autocorrelation time of each reaction-coordinate observable
       over a chosen production region, and the statistical inefficiency
       g = 1 + 2*tau that Chodera defines as "the number of correlated timeseries
       samples needed to produce a single effectively uncorrelated sample".

    2. Chodera's equilibration detection: the discard point t0 is scanned and the
       value chosen that maximises the effective sample size of what remains,
       rather than being read off block means by eye.

       The guide records a caveat that applies here: "Care must be taken in the
       case that the simulation is insufficiently long to sample many transitions
       among kinetically metastable states, however, or else this approach can
       simply result in restricting the production region to the last sampled
       metastable basin." The output flags that case.

    3. The effective sample size, which is what decides how many further QM/MM
       frames are worth running.

WHAT IT DOES NOT SETTLE
    The guide is explicit that "no single method described here has emerged as a
    clear best practice". The number produced here is an estimate conditioned on
    the observable and the method, and should be reported as such.

Usage:
    python3 sampling_quality.py [--dat <rxn_coord_per_frame_full.dat>]
Standard library only.
"""
import argparse
import math
import os


def read_series(path):
    """Columns of the reaction-coordinate trace, by header name."""
    lines = [l.rstrip("\n") for l in open(path) if l.strip()]
    hdr = [h.strip() for h in lines[0].lstrip("#").split("\t") if h.strip()]
    cols = {h: [] for h in hdr[1:]}
    frames = []
    for l in lines[1:]:
        if l.startswith("#"):
            continue
        p = l.split("\t")
        if len(p) < len(hdr):
            continue
        frames.append(int(p[0]))
        for k, h in enumerate(hdr[1:], start=1):
            cols[h].append(float(p[k]))
    return frames, cols


def acf_tau(x, max_lag=None):
    """Integrated autocorrelation time, summed to the first zero crossing.

    This is the standard estimator and is the one implied by the statistical
    inefficiency g = 1 + 2*tau. It is only meaningful for a stationary series,
    which is why the caller checks stationarity first.
    """
    n = len(x)
    m = sum(x) / n
    var = sum((v - m) ** 2 for v in x) / n
    if var <= 0:
        return float("nan")
    if max_lag is None:
        max_lag = min(n // 4, 20000)
    tau = 0.0
    for lag in range(1, max_lag):
        c = sum((x[i] - m) * (x[i + lag] - m) for i in range(n - lag))
        c /= (n - lag) * var
        if c <= 0:
            break
        tau += c
    return tau


def drift_test(x, nblock=10):
    """Is the mean still moving? Compares the first and last block against the
    within-block scatter. A stationary series has a drift comparable to or
    smaller than its fluctuation amplitude."""
    n = len(x)
    w = n // nblock
    if w < 2:
        return float("nan"), float("nan")
    means, sds = [], []
    for b in range(nblock):
        blk = x[b*w:(b+1)*w]
        mu = sum(blk) / len(blk)
        means.append(mu)
        sds.append(math.sqrt(sum((v-mu)**2 for v in blk) / (len(blk)-1)))
    return abs(means[-1] - means[0]), sum(sds) / len(sds)


def main():
    home = os.path.expanduser("~")
    ap = argparse.ArgumentParser()
    ap.add_argument("--dat",
                    default=f"{home}/system_development/04_amber_md/11_analysis/"
                            f"rxn_coord_per_frame_full.dat")
    ap.add_argument("--site", default="cha2",
                    help="which chorismate site the substrate occupies")
    args = ap.parse_args()

    if not os.path.exists(args.dat):
        raise SystemExit(f"not found: {args.dat}")
    frames, cols = read_series(args.dat)
    n = len(frames)
    print(f"{os.path.basename(args.dat)}: {n} frames, one per picosecond\n")

    keys = [k for k in cols if k.startswith(args.site)]
    if not keys:
        keys = list(cols)[:3]

    # ---------------------------------------------------- stationarity first
    print("=" * 76)
    print("Is each observable stationary? A correlation time is only defined if so.")
    print("=" * 76)
    print(f"{'observable':<14}{'mean':>9}{'sd':>9}{'drift':>9}{'fluct':>9}   verdict")
    print("-" * 76)
    usable = []
    for k in keys:
        x = cols[k]
        m = sum(x)/len(x)
        s = math.sqrt(sum((v-m)**2 for v in x)/(len(x)-1))
        d, f = drift_test(x)
        ok = d < 2*f
        if ok:
            usable.append(k)
        print(f"{k:<14}{m:>9.3f}{s:>9.3f}{d:>9.3f}{f:>9.3f}   "
              f"{'stationary' if ok else 'STILL DRIFTING'}")
    print()
    print("  drift is the change between the first and last tenth of the record;")
    print("  fluct is the mean within-block standard deviation. A series whose")
    print("  drift exceeds twice its fluctuation is not stationary and its")
    print("  autocorrelation measures the drift rather than the memory.")
    if not usable:
        print("\n  No observable is stationary. Report that, and do not quote an")
        print("  effective sample size from this trajectory.")
        return

    # ------------------------------------- Chodera's equilibration detection
    print("\n" + "=" * 76)
    print("Choosing the equilibration point by maximising the effective sample size")
    print("=" * 76)
    print("  Chodera (2016): scan the discard point t0 and take the value that")
    print("  leaves the most effectively uncorrelated samples in what remains.")
    print()
    best = {}
    for k in usable:
        x = cols[k]
        rows = []
        for t0 in range(0, min(n//2, 25000), 1000):
            seg = x[t0:]
            if len(seg) < 2000:
                break
            tau = acf_tau(seg, max_lag=min(len(seg)//4, 8000))
            if tau != tau or tau <= 0:
                continue
            g = 1 + 2*tau
            rows.append((t0, tau, g, len(seg)/g))
        if not rows:
            continue
        b = max(rows, key=lambda r: r[3])
        best[k] = b
        print(f"  {k}")
        print(f"    {'t0 / ps':>9}{'tau / ps':>10}{'g':>9}{'N_eff':>9}")
        for t0, tau, g, ne in rows:
            mark = "   <- maximum" if (t0, tau, g, ne) == b else ""
            print(f"    {t0:>9}{tau:>10.0f}{g:>9.1f}{ne:>9.1f}{mark}")
        print()

    # ------------------------------------------------------------- the answer
    print("=" * 76)
    print("Effective sample size")
    print("=" * 76)
    for k, (t0, tau, g, ne) in best.items():
        print(f"  {k:<14} discard {t0:>6} ps   tau {tau:>6.0f} ps   "
              f"g {g:>6.1f}   N_eff {ne:>6.1f}")
    if best:
        ne_all = [v[3] for v in best.values()]
        t0_all = [v[0] for v in best.values()]
        print()
        print(f"  Across these observables N_eff ranges {min(ne_all):.1f} to "
              f"{max(ne_all):.1f},")
        print(f"  with the discard point between {min(t0_all)} and {max(t0_all)} ps.")
        print()
        if max(t0_all) > 0.4 * n:
            print("  WARNING: the method has selected a discard point covering more")
            print("  than two fifths of the record. Grossfield et al. note this can")
            print("  happen when the simulation is too short to sample transitions")
            print("  between metastable states, in which case the method 'can simply")
            print("  result in restricting the production region to the last sampled")
            print("  metastable basin'. Treat the result with caution.")
        print("  The guide emphasises that 'no single method described here has")
        print("  emerged as a clear best practice', so this is an estimate")
        print("  conditioned on the observable and the method, not a determination.")


if __name__ == "__main__":
    main()
