#!/usr/bin/env bash
# patch_spring_and_cleanup.sh - two changes before the thirty frames are run.
#
# 1. THE SCAN RESTRAINT STRENGTH
#    The restrained scan did not pass through the transition state. In every
#    frame examined the achieved distances sat 0.18 to 0.35 A on the reactant
#    side of their targets while approaching the barrier, then flipped to the
#    product side once past it, so the reaction coordinate jumped by more than an
#    angstrom between adjacent windows and no window sat at the top.
#
#    Testing four spring constants on one frame, through the five windows
#    spanning the barrier, using the production driver unmodified apart from the
#    constant:
#
#        400  kJ/mol/A^2   largest deviation 0.308 A   r jumps -0.679 -> +0.462
#        1000               0.104
#        2500               0.038               r steps -0.576 -0.410 -0.245
#                                                        -0.076 +0.090
#        6000               0.015
#
#    2500 is adopted. It holds the target to well within the window spacing, and
#    the path now traverses the barrier rather than stepping over it: window 12
#    lands at r = -0.245 where the converged bands place the saddle, -0.26 +/-
#    0.08 across ten frames.
#
#    ON THE UNITS, WHICH MATTER HERE
#    The ORCA manual specifies the Restraint spring constant in kJ mol^-1 unit^-2.
#    The production value of 400 was therefore about 96 kcal mol^-1 A^-2, five
#    times weaker than the 500 kcal mol^-1 A^-2 used by Claeyssens et al. (2005).
#    The adopted 2500 kJ is 597 kcal, within twenty per cent of theirs. The test
#    converged independently on the published strength.
#
#    ON WHY TWO RESTRAINTS RATHER THAN ONE
#    Claeyssens restrain the reaction coordinate itself, leaving the system free
#    to distribute a given value between the two bonds. ORCA 6.0's Manage_Colvar
#    accepts only Distance, Angle, Dihedral and CoordNumber, with no linear
#    combination, so both distances are restrained separately. That removes one
#    degree of freedom and is why a stronger constant is needed: the system
#    cannot relieve strain by trading one bond against the other.
#
# 2. CLEANING UP AFTER THE BAND
#    A converged frame directory holds about 13 GB, of which 4.5 is an
#    approximate Hessian and 0.65 a full-system trajectory of every image at
#    every iteration. Thirty frames would be roughly 390 GB on a shared
#    filesystem. The trajectory of the quantum region along the same path is
#    kept, as are the converged geometries, the path summary and every input.
#
#    The Hessian is NOT removed, because it is what a restart or continuation of
#    the transition-state optimisation would need, and three frames are currently
#    doing exactly that.

set -euo pipefail
cd "$HOME/system_development/05_qmmm" || exit 1

# ---------------------------------------------------------------- 1. the spring
T=step19c_scan_product.sh
[[ -f "$T" ]] || { echo "FAIL: $T not found"; exit 1; }
cp "$T" "$T.bak_spring"
old=$(grep -c '^SPRING=400' "$T" || true)
if [[ "$old" == "0" ]]; then
  echo "NOTE: SPRING=400 not found in $T; current setting:"
  grep -n '^SPRING=' "$T" || echo "  none"
else
  sed -i 's/^SPRING=400.*/SPRING=2500.0   # kJ\/mol\/A^2; see patch_spring_and_cleanup.sh/' "$T"
  echo "spring set:"; grep -n '^SPRING=' "$T"
fi

# ------------------------------------------------------------- 2. the cleanup
G=step19a_ensemble_prepare.sh
[[ -f "$G" ]] || { echo "FAIL: $G not found"; exit 1; }
cp "$G" "$G.bak_cleanup"

python3 - "$G" <<'PY'
import sys
from pathlib import Path
p = Path(sys.argv[1]); t = p.read_text()

if "neb_MEP_ALL_trj" in t:
    print("cleanup already present"); raise SystemExit

# add after the NEB job's convergence report, wherever that is written
import re
m = re.search(r"^(\s*)echo '.*NEB.*(PASS|CONVERGED|converged).*'\s*$", t, re.M)
if not m:
    m = re.search(r"^(\s*)echo 'grep -q \"THE NEB OPTIMIZATION HAS CONVERGED\".*$", t, re.M)
if not m:
    print("could not find where the NEB job reports convergence.")
    print("Add this line to the generated neb.pbs by hand, after the check:")
    print("  rm -f neb_MEP_ALL_trj.xyz neb_MEP_trj.xyz neb_initial_path_trj.xyz neb*.tmp")
    raise SystemExit
line, indent = m.group(0), m.group(1)
add = (line + "\n" + indent +
       "echo '# the full-system trajectories are large and the quantum-region'\n" + indent +
       "echo '# versions of the same paths are kept; the Hessian is kept because'\n" + indent +
       "echo '# a restart of the transition-state optimisation would need it'\n" + indent +
       "echo 'rm -f neb_MEP_ALL_trj.xyz neb_MEP_trj.xyz neb_initial_path_trj.xyz "
       "neb_MEP_ALL.activeRegion_trj.xyz neb*.tmp neb_im*.gbw 2>/dev/null'")
t = t.replace(line, add, 1)
p.write_text(t)
print("cleanup added to the generated NEB job")
PY

bash -n "$T" && bash -n "$G" && echo "both generators still valid"
echo
echo "Verify by regenerating one frame:"
echo "  bash step19c_scan_product.sh 11630 >/dev/null 2>&1"
echo "  grep -n 'Spring' 19_ensemble/frame_11630/scan/run_scan.sh | head -3"
echo "  grep -n 'SPRING=' 19_ensemble/frame_11630/scan/run_scan.sh"
