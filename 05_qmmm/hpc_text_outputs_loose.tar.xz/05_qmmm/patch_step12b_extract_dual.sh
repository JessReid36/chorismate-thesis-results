#!/usr/bin/env bash
# patch_step12b_extract_dual.sh - let the extractor read frames from either
# trajectory file.
#
# WHY
#   The production run was extended by 40 ns in a separate job, so the trajectory
#   now lives in two files: prod.nc holding frames 0 to 19999 and prod_ext.nc
#   holding the next 40000. They are one continuous trajectory, since the
#   extension restarted from the first run's restart file with velocities.
#
#   Frames selected from the extension are numbered 0 to 39999 within their own
#   file, which collides with the numbering of the first run. Frame 13320 of the
#   extension is production frame 33320 and a different structure from frame
#   13320 of prod.nc, but nothing in the manifest or the output filename would
#   distinguish them.
#
# WHAT THIS CHANGES
#   The extractor opens both files and chooses between them by frame number: a
#   frame below the first file's length is read from prod.nc, and one at or above
#   it is read from prod_ext.nc at the index less that length. The boundary is
#   taken from the first file's own header rather than assumed, so it stays
#   correct if either trajectory is ever regenerated at a different length.
#
#   Selected extension frames must therefore be renumbered onto the continuous
#   scale before extraction, by adding the length of the first trajectory to both
#   the frame and prod_ps columns. renumber_ext_manifest.py does that.
#
#   With this in place the manifest alone determines which structure is
#   extracted, and no argument has to be remembered at the call site.

set -euo pipefail
T="$HOME/system_development/phase1_system_dev/step12b_extract.sh"
[[ -f "$T" ]] || { echo "FAIL: $T not found"; exit 1; }
cp "$T" "$T.bak"
echo "backup: $T.bak"

python3 - "$T" <<'PY'
import sys
from pathlib import Path
p = Path(sys.argv[1]); t = p.read_text()

# 1. define the second trajectory alongside the first
old = 'traj="$root/04_amber_md/10c_production/prod.nc"'
new = ('traj="$root/04_amber_md/10c_production/prod.nc"\n'
       '# the production run was extended; the two files are one trajectory\n'
       'traj2="$root/04_amber_md/10d_production_extend/prod_ext.nc"')
assert old in t, "trajectory definition not found"
t = t.replace(old, new, 1)

# 2. the presence check should not fail if the extension does not exist yet
old = 'for f in "$prmtop" "$traj" "$manifest"; do [[ -s "$f" ]] || { echo "FAIL missing $f"; exit 1; }; done'
new = ('for f in "$prmtop" "$traj" "$manifest"; do [[ -s "$f" ]] || { echo "FAIL missing $f"; exit 1; }; done\n'
       '[[ -s "$traj2" ]] || { echo "note: no extension trajectory at $traj2; "\\\n'
       '  "only frames of the first run can be extracted"; traj2=""; }')
assert old in t, "presence check not found"
t = t.replace(old, new, 1)

# 3. pass it to the python block
old = 'python3 - "$prmtop" "$traj" "$manifest" "$outdir" <<\'PY\''
new = 'python3 - "$prmtop" "$traj" "$manifest" "$outdir" "$traj2" <<\'PY\''
assert old in t, "python invocation not found"
t = t.replace(old, new, 1)

old = 'prmtop, traj, manifest, outdir = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]'
new = ('prmtop, traj, manifest, outdir = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]\n'
       'traj2 = sys.argv[5] if len(sys.argv) > 5 and sys.argv[5] else None')
assert old in t, "argument unpacking not found"
t = t.replace(old, new, 1)

# 4. open the second file and route frame requests by index
old = '''H=nc_open(traj); assert H["atom"]==natom, "atom mismatch"
cvar=next(v for v in H["rec"] if v["name"]=="coordinates")
lvar=next((v for v in H["rec"] if v["name"]=="cell_lengths"),None)
avar=next((v for v in H["rec"] if v["name"]=="cell_angles"),None)
def frame(i):
    o=cvar["begin"]+i*H["recsize"]
    xyz=np.array(np.memmap(traj,dtype=">f4",mode="r",offset=o,shape=(natom,3)),float)
    box=[0.0,0.0,0.0,90.0,90.0,90.0]
    if lvar is not None:
        bo=lvar["begin"]+i*H["recsize"]; box[:3]=list(np.array(np.memmap(traj,dtype=">f8",mode="r",offset=bo,shape=(3,)),float))
    if avar is not None:
        ao=avar["begin"]+i*H["recsize"]; box[3:]=list(np.array(np.memmap(traj,dtype=">f8",mode="r",offset=ao,shape=(3,)),float))
    return xyz,box'''
new = '''def open_traj(path):
    """Header and the three record variables of one trajectory file."""
    H=nc_open(path); assert H["atom"]==natom, "atom mismatch in %s"%path
    return {"path":path, "H":H,
            "c":next(v for v in H["rec"] if v["name"]=="coordinates"),
            "l":next((v for v in H["rec"] if v["name"]=="cell_lengths"),None),
            "a":next((v for v in H["rec"] if v["name"]=="cell_angles"),None)}

T1=open_traj(traj)
T2=open_traj(traj2) if traj2 else None
N1=T1["H"]["frames"]
print("trajectory 1: %s, %d frames"%(os.path.basename(traj),N1))
if T2:
    print("trajectory 2: %s, %d frames"%(os.path.basename(traj2),T2["H"]["frames"]))
    print("frames 0 to %d are read from the first, %d and above from the second"
          %(N1-1,N1))

def frame(i):
    """Read production frame i, spanning the two files.

    The two trajectories are one run: the extension restarted from the first
    file's restart with velocities. Production frame i therefore lives in the
    first file if i is below its length and in the second at i-N1 otherwise.
    The boundary comes from the first file's header, not from an assumed
    length."""
    if i < N1 or T2 is None:
        t, j = T1, i
        if i >= N1:
            sys.exit("FAIL frame %d is beyond %s (%d frames) and no extension "
                     "trajectory was given"%(i,os.path.basename(traj),N1))
    else:
        t, j = T2, i - N1
        if j >= t["H"]["frames"]:
            sys.exit("FAIL frame %d is beyond the end of both trajectories"%i)
    path, H, cvar, lvar, avar = t["path"], t["H"], t["c"], t["l"], t["a"]
    o=cvar["begin"]+j*H["recsize"]
    xyz=np.array(np.memmap(path,dtype=">f4",mode="r",offset=o,shape=(natom,3)),float)
    box=[0.0,0.0,0.0,90.0,90.0,90.0]
    if lvar is not None:
        bo=lvar["begin"]+j*H["recsize"]; box[:3]=list(np.array(np.memmap(path,dtype=">f8",mode="r",offset=bo,shape=(3,)),float))
    if avar is not None:
        ao=avar["begin"]+j*H["recsize"]; box[3:]=list(np.array(np.memmap(path,dtype=">f8",mode="r",offset=ao,shape=(3,)),float))
    return xyz,box'''
assert old in t, "the frame reader was not found in the expected form"
t = t.replace(old, new, 1)
p.write_text(t)
print("patched: the extractor now spans both trajectory files")
PY

bash -n "$T" && echo "syntax OK"
echo
echo "Renumber the extension manifest first, then extract:"
echo "  python3 renumber_ext_manifest.py <in.tsv> <out.tsv>"
