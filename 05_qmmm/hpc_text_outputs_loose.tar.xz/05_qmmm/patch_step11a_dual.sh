#!/usr/bin/env bash
# patch_step11a_dual.sh - make the RMSD trace span both trajectory files with a
# single reference structure.
#
# WHY
#   The production run is now in two files, prod.nc and prod_ext.nc, which are
#   one continuous trajectory. step11a measures RMSD against frame 0 of whichever
#   file it is given, so running it separately on each produces two traces with
#   different references whose absolute values cannot be compared.
#
#   That was adequate for measuring the correlation time, which is computed from
#   fluctuations about the mean and is unaffected by a constant offset in the
#   reference. It is not adequate for a figure, for judging equilibration across
#   the whole run, or for any statement about how far the structure has drifted.
#
#   It also leaves the trace numbered differently from the frame manifest, which
#   now runs continuously from 0 to 59999 after renumbering. One trace with one
#   reference and one numbering removes a class of error that has already cost
#   time elsewhere in this project.
#
# WHAT THIS CHANGES
#   The script opens both files, takes its reference from frame 0 of the first,
#   and walks frames 0 to N1+N2-1 continuously, reading each from whichever file
#   holds it. The boundary is the first file's own record count, read from its
#   header rather than assumed.
#
#   The output path changes to rmsd_vs_time_full.dat so the existing traces are
#   not overwritten.
#
#   This is the same dual-trajectory logic applied to step12b_extract.sh, so the
#   two scripts index frames identically.

set -euo pipefail
SRC="$HOME/system_development/phase1_system_dev/step11a_rmsd.sh"
OUT="$HOME/system_development/05_qmmm/step11a_rmsd_full.sh"
[[ -f "$SRC" ]] || { echo "FAIL: $SRC not found"; exit 1; }
cp "$SRC" "$OUT"
echo "working from a copy: $OUT"

python3 - "$OUT" <<'PY'
import sys
from pathlib import Path
p = Path(sys.argv[1]); t = p.read_text()

# 1. second trajectory and a distinct output
old = 'traj="$root/04_amber_md/10c_production/prod.nc"'
new = ('traj="$root/04_amber_md/10c_production/prod.nc"\n'
       '# the production run was extended; the two files are one trajectory\n'
       'traj2="$root/04_amber_md/10d_production_extend/prod_ext.nc"')
assert old in t, "trajectory definition not found"
t = t.replace(old, new, 1)

old = 'outdat="$outdir/rmsd_vs_time.dat"'
new = 'outdat="$outdir/rmsd_vs_time_full.dat"'
assert old in t, "output path not found"
t = t.replace(old, new, 1)

old = 'for f in "$prmtop" "$traj"; do [[ -s "$f" ]] || { echo "FAIL missing $f"; exit 1; }; done'
new = ('for f in "$prmtop" "$traj" "$traj2"; do [[ -s "$f" ]] || { echo "FAIL missing $f"; exit 1; }; done')
assert old in t, "presence check not found"
t = t.replace(old, new, 1)

old = 'python3 - "$prmtop" "$traj" "$outdat" <<\'PY\''
new = 'python3 - "$prmtop" "$traj" "$outdat" "$traj2" <<\'PY\''
assert old in t, "python invocation not found"
t = t.replace(old, new, 1)

old = 'prmtop, traj, outdat = sys.argv[1], sys.argv[2], sys.argv[3]'
new = ('prmtop, traj, outdat = sys.argv[1], sys.argv[2], sys.argv[3]\n'
       'traj2 = sys.argv[4]')
assert old in t, "argument unpacking not found"
t = t.replace(old, new, 1)

# 2. route frame reads between the two files, reference from the first
old = '''x0,b0=frame(0); ref=image(x0,b0)[bb_idx]; rms=np.empty(H["frames"])
for i in range(H["frames"]):
    xi,bi=frame(i); rms[i]=kabsch(image(xi,bi)[bb_idx],ref)'''
new = '''# The two files are one trajectory: the extension restarted from the first
# run's restart with velocities. Production frame i is read from the first file
# if i is below its record count and from the second at i-N1 otherwise. The
# reference is frame 0 of the FIRST file in both cases, so the whole trace is
# measured against one structure and the values are comparable throughout.
H2=nc_open(traj2); assert H2["atom"]==natom, "atom mismatch in the extension"
cvar2=next(v for v in H2["rec"] if v["name"]=="coordinates")
lvar2=next((v for v in H2["rec"] if v["name"]=="cell_lengths"),None)
avar2=next((v for v in H2["rec"] if v["name"]=="cell_angles"),None)
N1=H["frames"]; N2=H2["frames"]; NT=N1+N2
def frame2(j):
    o=cvar2["begin"]+j*H2["recsize"]
    xyz=np.array(np.memmap(traj2,dtype=">f4",mode="r",offset=o,shape=(natom,3)),float)
    box=[0.0,0.0,0.0,90.0,90.0,90.0]
    if lvar2 is not None:
        bo=lvar2["begin"]+j*H2["recsize"]; box[:3]=list(np.array(np.memmap(traj2,dtype=">f8",mode="r",offset=bo,shape=(3,)),float))
    if avar2 is not None:
        ao=avar2["begin"]+j*H2["recsize"]; box[3:]=list(np.array(np.memmap(traj2,dtype=">f8",mode="r",offset=ao,shape=(3,)),float))
    return xyz,box
def frame_any(i):
    return frame(i) if i < N1 else frame2(i-N1)

print("  trajectory 1: %d frames, trajectory 2: %d frames, total %d"%(N1,N2,NT))
print("  reference: frame 0 of the first trajectory, for the whole trace")
x0,b0=frame(0); ref=image(x0,b0)[bb_idx]; rms=np.empty(NT)
for i in range(NT):
    xi,bi=frame_any(i); rms[i]=kabsch(image(xi,bi)[bb_idx],ref)'''
assert old in t, "the RMSD loop was not found in the expected form"
t = t.replace(old, new, 1)

# 3. the summary lines still refer to H["frames"]
t = t.replace('w=max(1,H["frames"]//10)', 'w=max(1,NT//10)')
t = t.replace('print("  backbone atoms %d   protein molecules %s   frames %d"%(len(bb_idx),prot_mols,H["frames"]))',
              'print("  backbone atoms %d   protein molecules %s   frames %d"%(len(bb_idx),prot_mols,NT))')
p.write_text(t)
print("patched: one trace across both files, referenced to production frame 0")
PY

bash -n "$OUT" && echo "syntax OK"
echo
echo "Run it under the batch system: 60000 Kabsch fits."
