#!/usr/bin/env bash
# patch_runner_qstat.sh - stop the batch runner resubmitting jobs that are
# already running.
#
# WHAT WENT WRONG
#   The runner decided whether a stage was done by looking for its output: a scan
#   was considered outstanding unless win_20.pdb existed. That file appears only
#   when a scan finishes, so a scan that is running looks exactly like one that
#   has never started, and calling stage2 twice submitted a second job into a
#   directory a first job was still writing.
#
#   This is the same fault that caused duplicate submissions earlier in the
#   project. The only reliable test of whether something is running is the queue,
#   not the filesystem.
#
# THE FIX
#   A single helper that asks qstat whether a job for this frame and stage is
#   already present, and a guard on every submission that uses it. The job names
#   follow the pattern cm19_<letter><frame>, with r for the reactant
#   optimisation, s for the scan, p for the product optimisation and n for the
#   band; qstat truncates them, so the comparison is on the leading characters.

set -euo pipefail
T="$HOME/system_development/05_qmmm/run_ensemble_batched.sh"
[[ -f "$T" ]] || { echo "FAIL: $T not found"; exit 1; }
cp "$T" "$T.bak_qstat"
echo "backup: $T.bak_qstat"

python3 - "$T" <<'PY'
import sys
from pathlib import Path
p = Path(sys.argv[1]); t = p.read_text()

if "in_queue()" in t:
    print("already patched"); raise SystemExit

old = 'running()    { qstat -u "$USER" 2>/dev/null | grep -c "cm19_" ; }'
new = '''running()    { qstat -u "$USER" 2>/dev/null | grep -c "cm19_" ; }

# Is a job for this frame and stage already in the queue? The queue is the only
# reliable test: output files appear when a stage finishes, so a running job and
# an unstarted one look identical on disk. Job names are cm19_<letter><frame>
# and qstat truncates them, so match on the leading characters.
in_queue() {  # in_queue <frame> <letter>
  local pat="cm19_$2${1#0}"
  qstat -u "$USER" 2>/dev/null | awk '{print $4}' | \\
    sed 's/\\*$//' | grep -q "^${pat:0:10}" && return 0
  return 1
}'''
assert old in t, "could not find the running() helper"
t = t.replace(old, new, 1)

# guard every submission
subs = [
    ('    qstat -u "$USER" 2>/dev/null | grep -q "cm19_r${f:1}" && continue',
     '    in_queue "$f" r && { echo "  $f already queued"; continue; }'),
]
for a, b in subs:
    if a in t:
        t = t.replace(a, b, 1)

# stage2, stage3, stage4 have no guard at all; add one to each
for stage, letter, what in (("stage2", "s", "scan"),
                            ("stage3", "p", "product optimisation"),
                            ("stage4", "n", "band")):
    marker = {"stage2": '    [[ -s "$ENS/frame_$f/scan.pbs" ]]',
              "stage3": '    [[ -s "$ENS/frame_$f/product_opt.pbs" ]]',
              "stage4": '    [[ -s "$ENS/frame_$f/tsguess.pdb" ]]'}[stage]
    assert marker in t, f"could not find the {stage} guard point"
    t = t.replace(marker,
                  f'    in_queue "$f" {letter} && {{ echo "  $f already running a {what}"; continue; }}\n'
                  + marker, 1)

p.write_text(t)
print("patched: every submission now checks the queue first")
PY

bash -n "$T" && echo "syntax OK"
grep -n "in_queue" "$T" | head
