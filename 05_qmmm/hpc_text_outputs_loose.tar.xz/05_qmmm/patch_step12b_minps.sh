#!/usr/bin/env bash
# patch_step12b_minps.sh - restrict frame selection to the equilibrated portion
# of the production trajectory.
#
# WHY
#   The backbone root-mean-square deviation of the production run rises
#   monotonically across the first half and is stable thereafter. In two-nanosecond
#   blocks the means are
#
#       0-2 ns   1.982   (sd 0.454)
#       2-4      2.739   (0.209)
#       4-6      2.544   (0.178)
#       6-8      2.818   (0.166)
#       8-10     3.189   (0.250)
#      10-12     3.672   (0.264)
#      12-14     3.520   (0.169)
#      14-16     3.811   (0.266)
#      16-18     3.771   (0.208)
#      18-20     3.590   (0.127)
#
#   The two halves differ by 1.018 A against a pooled standard deviation of
#   0.380, and the within-block scatter is largest in the first block and settles
#   later. The structure is therefore still relaxing over the first ten
#   nanoseconds and only the second half samples an equilibrated ensemble.
#
#   Frames drawn from the relaxing portion are not from the same distribution as
#   frames drawn afterwards. Discarding the equilibration period is standard
#   practice and does not depend on whether its effect is visible in the
#   barriers; with the four and six frames presently available on either side of
#   ten nanoseconds, a difference of five kcal/mol would not be resolvable
#   (Welch t = 1.48 on 5.1 degrees of freedom), so the barriers can neither
#   confirm nor exclude one.
#
# WHAT THIS ADDS
#   A --min-ps argument, defaulting to 11000, which excludes every frame before
#   that time from the candidate pool. The default carries a one-nanosecond
#   margin beyond the point at which the block means stop rising, so that no
#   selected frame sits near the boundary.
#
#   Nothing else changes. The three angular conditions, the contact cut and the
#   maximin time separation are untouched.

set -euo pipefail
[[ -f step12b_nac_select.py ]] || { echo "run from the directory holding step12b_nac_select.py"; exit 1; }
cp step12b_nac_select.py step12b_nac_select.py.bak
echo "backup: step12b_nac_select.py.bak"

python3 - <<'PY'
from pathlib import Path
p = Path("step12b_nac_select.py"); t = p.read_text()

old = '''    ap.add_argument("--stride", type=int, default=5)'''
new = '''    ap.add_argument("--stride", type=int, default=5)
    ap.add_argument("--min-ps", type=float, default=11000.0,
                    dest="min_ps",
                    help="exclude frames earlier than this time in the "
                         "production trajectory. The backbone RMSD rises "
                         "monotonically over the first ten nanoseconds and is "
                         "stable thereafter, so earlier frames do not sample "
                         "the equilibrated ensemble. The default carries a "
                         "one-nanosecond margin beyond that point.")'''
assert old in t, "stride argument not found"
t = t.replace(old, new, 1)

old2 = '''    for i in range(0, H["frames"], args.stride):'''
new2 = '''    # One frame is written per picosecond, so the frame index and the time in
    # picoseconds are the same number. Starting the scan at the first
    # equilibrated frame is equivalent to filtering afterwards but avoids
    # reading coordinates that would only be discarded.
    i0 = int(args.min_ps)
    if i0 > 0:
        print(f"excluding the first {i0} frames as pre-equilibration; "
              f"{H['frames'] - i0} remain")
    for i in range(i0, H["frames"], args.stride):'''
assert old2 in t, "scanning loop not found"
t = t.replace(old2, new2, 1)

old3 = '''    print(f"scanning every {args.stride}th of {H['frames']} frames "'''
new3 = '''    print(f"scanning every {args.stride}th frame from {int(args.min_ps)} ps "'''
if old3 in t:
    t = t.replace(old3, new3, 1)
    t = t.replace('''          f"at {args.site} against the full NAC criterion ...")''',
                  '''          f"onward at {args.site} against the full NAC criterion ...")''', 1)
p.write_text(t)
print("patched: --min-ps added, default 11000")
PY

python3 -c "import ast;ast.parse(open('step12b_nac_select.py').read())" && echo "syntax OK"
echo
echo "To select thirty frames from the equilibrated portion:"
echo "  python3 step12b_nac_select.py --n 30 --stride 1 \\"
echo "      --manifest 12_frame_selection/selection_manifest.tsv \\"
echo "      --out 12_frame_selection/selection_manifest_eq30.tsv"
