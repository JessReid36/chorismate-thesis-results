#!/usr/bin/env bash
# patch_step11c_dual.sh - extend the reaction-coordinate trace across both
# trajectory files.
#
# WHY THIS OBSERVABLE
#   The correlation time measured from the backbone deviation against a fixed
#   reference gave 699 ps or 2349 ps depending on which structure was used as the
#   reference, a disagreement of 3.4-fold. Grossfield et al. (2018) explain why
#   neither is meaningful: the correlation time is defined for a stationary
#   series, "meaning that tau is independent of t", and a series whose mean is
#   still rising is not stationary. They also state that the deviation against a
#   single reference "should really be considered as another equilibration test"
#   rather than a sampling test, and "is not even a particularly good test of
#   equilibration".
#
#   They recommend instead comparing "auto-correlation times for individual
#   observables". The distances this script measures are the right ones here:
#   they fluctuate about a mean rather than drifting, so their autocorrelation is
#   defined, and they are what the barrier depends on, where the backbone
#   deviation of a trimer is not.
#
# WHAT THIS CHANGES
#   The script reads both trajectory files as one continuous run, using the same
#   routing as the patched step11a and step12b: frames below the first file's
#   record count come from it, the rest from the extension at index less that
#   count. The output goes to rxn_coord_per_frame_full.dat so the existing trace
#   is untouched.

set -euo pipefail
SRC="$HOME/system_development/phase1_system_dev/step11c_rxn_coord.sh"
OUT="$HOME/system_development/05_qmmm/step11c_rxn_coord_full.sh"
[[ -f "$SRC" ]] || { echo "FAIL: $SRC not found"; exit 1; }
cp "$SRC" "$OUT"
echo "working from a copy: $OUT"

python3 - "$OUT" <<'PY'
import sys, re
from pathlib import Path
p = Path(sys.argv[1]); t = p.read_text()

old = 'traj="$root/04_amber_md/10c_production/prod.nc"'
new = ('traj="$root/04_amber_md/10c_production/prod.nc"\n'
       '# the production run was extended; the two files are one trajectory\n'
       'traj2="$root/04_amber_md/10d_production_extend/prod_ext.nc"')
assert old in t, "trajectory definition not found"
t = t.replace(old, new, 1)

old = 'for f in "$prmtop" "$traj"; do [[ -s "$f" ]] || { echo "FAIL missing $f"; exit 1; }; done'
new = 'for f in "$prmtop" "$traj" "$traj2"; do [[ -s "$f" ]] || { echo "FAIL missing $f"; exit 1; }; done'
assert old in t, "presence check not found"
t = t.replace(old, new, 1)

old = 'python3 - "$prmtop" "$traj" "$outdir" <<\'PY\''
new = 'python3 - "$prmtop" "$traj" "$outdir" "$traj2" <<\'PY\''
assert old in t, "python invocation not found"
t = t.replace(old, new, 1)

old = 'prmtop, traj, outdir = sys.argv[1], sys.argv[2], sys.argv[3]'
new = ('prmtop, traj, outdir = sys.argv[1], sys.argv[2], sys.argv[3]\n'
       'traj2 = sys.argv[4]')
assert old in t, "argument unpacking not found"
t = t.replace(old, new, 1)

# the frame reader returns coordinates only; parameterise it by file
m = re.search(r'^def frame\(i\):\n(.*?)\n(?=\S)', t, re.M | re.S)
assert m, "frame reader not found"
body = m.group(0)
assert 'np.memmap(traj' in body, "frame reader does not use traj as expected"
new_reader = ('def frame_from(path,hdr,cv,i):\n'
              '    """One frame of one trajectory. Used for both files so there is a\n'
              '    single definition and no parallel version that can drift from it."""\n'
              '    off=cv["begin"]+i*hdr["recsize"]\n'
              '    return np.array(np.memmap(path,dtype=">f4",mode="r",offset=off,shape=(natom,3))[:maxidx],float)\n'
              'def frame(i):\n'
              '    return frame_from(traj,H,cvar,i)\n'
              'H2=nc_open(traj2); assert H2["atom"]==natom, "atom mismatch in the extension"\n'
              'cvar2=next(v for v in H2["rec"] if v["name"]=="coordinates")\n'
              'N1=H["frames"]; N2=H2["frames"]; NT=N1+N2\n'
              'def frame_any(i):\n'
              '    if i < N1:\n'
              '        return frame_from(traj,H,cvar,i)\n'
              '    return frame_from(traj2,H2,cvar2,i-N1)\n'
              'print("  trajectory 1: %d frames, trajectory 2: %d, total %d"%(N1,N2,NT))\n')
t = t.replace(body, new_reader, 1)

# the loop and the frame count
t = re.sub(r'for i in range\(H\["frames"\]\)', 'for i in range(NT)', t)
t = re.sub(r'range\(H\["frames"\]\)', 'range(NT)', t)
t = t.replace('frame(i)', 'frame_any(i)')
t = t.replace('def frame_any(i):\n    return frame_from(traj,H,cvar,i)', 'def frame(i):\n    return frame_from(traj,H,cvar,i)')
t = t.replace('rxn_coord_per_frame.dat', 'rxn_coord_per_frame_full.dat')
p.write_text(t)
print("patched: reads both files, writes rxn_coord_per_frame_full.dat")
PY

bash -n "$OUT" && echo "syntax OK"
grep -n "frame_from\|frame_any\|NT\|_full.dat" "$OUT" | head -10
