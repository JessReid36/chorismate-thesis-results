#!/usr/bin/env python3
"""
step19e_clean.py - remove ORCA scratch from converged ensemble reactant
optimisations. Reports before it deletes, and deletes only with --apply.

SAFETY MODEL
------------
This works from an explicit KEEP list rather than a delete list. Anything not
matched by a keep rule and not matched by a scratch rule is reported as
UNCLASSIFIED and left alone, so a file this script has never seen cannot be
deleted by accident.

Only frames whose reactant optimisation has converged are touched, and only
files belonging to that optimisation. Scan, product and NEB outputs are out of
scope entirely.

WHAT IS KEPT, AND WHY
  reactant_opt.inp          declares QMAtoms and ActiveAtoms; the durable record
                            of the region definitions, since ORCA deletes its
                            own -qm_atoms.tmp and -active_atoms.tmp on exit
  reactant_opt.out          energies, convergence, walltime
  reactant_opt.pdb          the optimised structure; the harvest is derived from
                            this and reactant_opt.inp, so both must survive for
                            the harvest to remain reproducible
  reactant_opt.gbw          converged wavefunction
  reactant_opt.densities    density container, needed for any later property or
                            electrostatic-potential evaluation
  reactant_opt_trj.dcd      the optimisation trajectory; the only record of the
                            path taken, and not regenerable without rerunning
  reactant_opt.mdrestart    restart point
  reactant_opt.pc.tmp       the point charges representing the MM environment
  reactant_opt_MM.*         force-field assignment: mmparam, mmindex, mmdim, gbw
  *-minimize-ener.csv       convergence trace
  *.log                     grad, int, md, mm, scf logs
  complex_solvated.ORCAFF.prms, frame_*.pdb, neb.inp, neb.pbs, *.pbs
                            inputs for this and later stages

WHAT IS TREATED AS SCRATCH
  Large per-SCF and per-gradient intermediates that ORCA regenerates on any
  rerun: grad.tmp, MM.grad.tmp, the exc/gpot/grho/opot/orho families, grid and
  gridx, EIJ, PDAT, K, S/T/V/H matrices, SHARK and SINV workspaces.

  H_DIST.prms.tmp is NOT treated as scratch. It is derived from the force-field
  file, and I have not established that it is regenerated rather than read, so
  it is left in place.

Usage
  python3 step19e_clean.py            # report only
  python3 step19e_clean.py --apply    # delete, after you have read the report
"""

import os
import re
import sys

HOME = os.path.expanduser("~")
ROOT = f"{HOME}/system_development/05_qmmm/19_ensemble"

KEEP_EXACT = {
    "reactant_opt.inp", "reactant_opt.out", "reactant_opt.pdb",
    "reactant_opt.gbw", "reactant_opt.densities", "reactant_opt.densitiesinfo",
    "reactant_opt_trj.dcd", "reactant_opt.mdrestart",
    "reactant_opt.mdrestart.resume", "reactant_opt.pc.tmp",
    "reactant_opt-minimize-ener.csv", "reactant_opt.property.txt",
    "reactant_opt.mdinput", "reactant_opt.hostnames",
    "reactant_opt.H_DIST.prms.tmp", "reactant_opt.maininp.tmp",
    "reactant_opt.citations.tmp", "reactant_opt-qm_atoms.tmp",
    "reactant_opt-active_atoms.tmp",
    "complex_solvated.ORCAFF.prms", "neb.inp", "neb.pbs", "ambpdb.err",
    "tempout.txt",
}
KEEP_PATTERNS = [
    r"^frame_\d+_CHA2\.pdb$",
    r"^reactant_opt\.pbs(\.out)?$",
    r"^reactant_opt.*\.log$",
    r"^reactant_opt_MM\.(gbw|mmparam|mmindex|mmdim|hostnames|en)\.?t?m?p?$",
    r"^reactant_opt_MM\.(mmparam|mmindex|mmdim)\.tmp$",
    r"^scan.*", r"^product_opt.*", r"^win_.*", r"^neb.*",
    r"^reactant\.pdb$", r"^product\.pdb$",
]
SCRATCH_PATTERNS = [
    r"^reactant_opt\.grad\.tmp$",
    r"^reactant_opt_MM\.grad\.tmp$",
    r"^reactant_opt_MM_MM\.grad\.tmp$",
    r"^reactant_opt\.(exc|gpot|grho|opot|orho)\d*\.tmp$",
    r"^reactant_opt\.(grid|shark_grid)\.tmp$",
    r"^reactant_opt\.gridx\d+\.tmp$",
    r"^reactant_opt\.(EIJ|PDAT|K|K0|P0|H|S|T|V|SM12|SP12|int|rot|E|en)\.tmp$",
    r"^reactant_opt\.(VAUXJ|VCDJ|VEXT|VM1EXT|SQRTVEXT|SQRTVJ)\.tmp$",
    r"^reactant_opt\.SHARK(INP|\.KPRSCR)\.tmp$",
    r"^reactant_opt\.SC0\.gridx\d+\.tmp$",
    r"^reactant_opt\.SINV\.gridx\d+_factor\.tmp$",
    r"^reactant_opt\.C0\.tmp$",
    r"^reactant_opt\.cpscfdata\.tmp\.\d+$",
    r"^reactant_opt\.propint\.tmp\.\d+$",
    r"^reactant_opt\.bas\d+$",
]


def classify(name):
    if name in KEEP_EXACT:
        return "keep"
    for p in KEEP_PATTERNS:
        if re.match(p, name):
            return "keep"
    for p in SCRATCH_PATTERNS:
        if re.match(p, name):
            return "scratch"
    return "unclassified"


def converged(d):
    f = os.path.join(d, "reactant_opt.out")
    if not os.path.exists(f):
        return False
    with open(f, errors="replace") as fh:
        return "The minimization has converged" in fh.read()


def human(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f}{u}"
        n /= 1024
    return f"{n:.1f}TB"


def main():
    apply = "--apply" in sys.argv
    frames = sorted(n for n in os.listdir(ROOT) if n.startswith("frame_"))

    total_scratch = 0
    unclassified = {}
    plan = []

    for name in frames:
        d = os.path.join(ROOT, name)
        if not converged(d):
            print(f"{name}: not converged, skipped")
            continue
        if not os.path.exists(os.path.join(d, "reactant_opt.pdb")):
            print(f"{name}: NO reactant_opt.pdb, skipped (harvest not reproducible)")
            continue

        s = 0
        files = []
        for fn in os.listdir(d):
            fp = os.path.join(d, fn)
            if not os.path.isfile(fp):
                continue
            c = classify(fn)
            if c == "scratch":
                sz = os.path.getsize(fp)
                s += sz
                files.append((fn, sz))
            elif c == "unclassified":
                unclassified.setdefault(fn, 0)
                unclassified[fn] += os.path.getsize(fp)
        total_scratch += s
        plan.append((name, s, files))
        print(f"{name}: {len(files)} scratch files, {human(s)}")

    print(f"\ntotal scratch across converged frames: {human(total_scratch)}")

    if unclassified:
        print(f"\nUNCLASSIFIED ({len(unclassified)} names) - not deleted, "
              f"not recognised by any rule:")
        for fn, sz in sorted(unclassified.items(), key=lambda kv: -kv[1])[:20]:
            print(f"    {fn:45s} {human(sz)}")
        print("  Review these. If any are scratch, add a rule; if any are needed,"
              " they are already safe.")

    if plan:
        big = sorted(plan[0][2], key=lambda kv: -kv[1])[:8]
        print(f"\nlargest scratch files in {plan[0][0]}:")
        for fn, sz in big:
            print(f"    {fn:45s} {human(sz)}")

    if not apply:
        print("\nREPORT ONLY. Nothing deleted. Re-run with --apply to delete.")
        return

    print("\ndeleting ...")
    freed = 0
    for name, s, files in plan:
        d = os.path.join(ROOT, name)
        for fn, sz in files:
            try:
                os.remove(os.path.join(d, fn))
                freed += sz
            except OSError as e:
                print(f"  could not remove {name}/{fn}: {e}")
    print(f"freed {human(freed)}")


if __name__ == "__main__":
    main()
