#!/usr/bin/env bash
# patch_step19a_nebts.sh - make the ensemble NEB generator write the reference
# protocol.
#
# WHY
#   step19a_ensemble_prepare.sh writes the nudged-elastic-band input from
#   scratch. The reference calculation, in 18_nebts/nebts.inp, uses NEB-TS with a
#   transition-state guess supplied as TS_PDBFile. The generator writes NEB-CI
#   with no guess. Every other directive is byte-identical.
#
#   The consequence was visible in the output. Bands started from a linear
#   interpolation with no guess had first segments of 1.85 to 3.67 A where the
#   reference path's is 0.642 A, and their early images relaxed below the
#   converged reactant, so the reported barrier was measured from a point the
#   band had left. The existing frames were corrected after the fact; this
#   corrects the generator, so that frames prepared in future are right when
#   they are written.
#
#   The divergence arose because this stage writes its input from scratch while
#   the scan stage copies its driver from the reference directory. The stage that
#   copies did not drift; the stage that rewrote did.
#
# WHAT THIS CHANGES
#   1. NEB-CI becomes NEB-TS in the generated input.
#   2. TS_PDBFile "tsguess.pdb" is added inside the %neb block.
#
#   The guess itself is staged by step19c_scan_product.sh, which owns the scan
#   and therefore knows which window is the maximum. That script is patched
#   separately by patch_step19c_tsguess.sh, and both must be applied.

set -euo pipefail
[[ -f step19a_ensemble_prepare.sh ]] || { echo "run from the directory holding step19a_ensemble_prepare.sh"; exit 1; }
cp step19a_ensemble_prepare.sh step19a_ensemble_prepare.sh.bak
echo "backup: step19a_ensemble_prepare.sh.bak"

python3 - <<'PY'
from pathlib import Path
p = Path("step19a_ensemble_prepare.sh"); t = p.read_text()

old = '''    echo "! QMMM B3LYP D3BJ def2-SVP def2/J RIJCOSX NEB-CI SlowConv TightSCF"'''
new = '''    echo "! QMMM B3LYP D3BJ def2-SVP def2/J RIJCOSX NEB-TS SlowConv TightSCF"'''
assert old in t, "the NEB-CI header line was not found"
t = t.replace(old, new, 1)

old2 = """    echo '  Product_PDBFile "product.pdb"'"""
new2 = """    echo '  Product_PDBFile "product.pdb"'
    echo '  TS_PDBFile "tsguess.pdb"'"""
assert old2 in t, "the Product_PDBFile line was not found"
t = t.replace(old2, new2, 1)

# the header comment still describes the superseded method
t = t.replace("#                       NEB-CI barrier",
              "#                       NEB-TS barrier, from the scan maximum as guess")
t = t.replace("15.94 kcal/mol against the fully characterised 16.00, agreeing to 0.06. NEB-CI",
              "15.94 kcal/mol against the fully characterised 16.00, agreeing to 0.06. NEB-TS")
p.write_text(t)
print("patched: NEB-TS with a transition-state guess")
PY

bash -n step19a_ensemble_prepare.sh && echo "syntax OK"
echo
echo "verify against the reference, directive lines only:"
echo "  the generated neb.inp should now differ from 18_nebts/nebts.inp"
echo "  only in the filenames it points at."
