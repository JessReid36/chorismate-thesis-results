#!/usr/bin/env bash
# patch_step19c_tsguess.sh - stage the transition-state guess alongside the
# product starting structure.
#
# WHY
#   The nudged-elastic-band calculation needs three structures: the two optimised
#   endpoints and a guess at the saddle. The scan produces all three. Its final
#   window becomes the product starting structure, and its highest-energy window
#   is the guess, which is how the reference calculation's tsguess.pdb was
#   obtained: it is byte-identical to win_11.pdb of the reference scan, and
#   window 11 is that scan's energy maximum.
#
#   This was previously done by hand for the reference and not at all for the
#   ensemble. Doing it in the script that owns the scan means the guess and the
#   endpoints always come from the same path.
#
# WHAT THIS ADDS
#   A step in the generated scan job that reads scan_energies.tsv after the scan
#   completes, finds the window of highest energy, and copies it to tsguess.pdb.
#   The job fails loudly if no maximum can be identified, rather than leaving the
#   band to start from nothing.

set -euo pipefail
[[ -f step19c_scan_product.sh ]] || { echo "run from the directory holding step19c_scan_product.sh"; exit 1; }
cp step19c_scan_product.sh step19c_scan_product.sh.bak
echo "backup: step19c_scan_product.sh.bak"

python3 - <<'PY'
from pathlib import Path
p = Path("step19c_scan_product.sh"); t = p.read_text()

anchor = """    echo 'tail -3 scan_progress.tsv 2>/dev/null'"""
addition = """    echo '# the transition-state guess for the band is the highest-energy window'
    echo '# of this scan, which is how the reference calculation obtained its own'
    echo 'W=$(sort -t$\\'\\\\t\\' -k3 -g scan_energies.tsv | tail -1 | cut -f1)'
    echo 'if [ -n "$W" ] && [ -s "win_${W}.pdb" ]; then'
    echo '  cp "win_${W}.pdb" ../tsguess.pdb'
    echo '  echo "TSGUESS window $W"'
    echo 'else'
    echo '  echo TSGUESS_MISSING; exit 1'
    echo 'fi'
    echo 'tail -3 scan_progress.tsv 2>/dev/null'"""
assert anchor in t, "the scan job tail was not found"
t = t.replace(anchor, addition, 1)
p.write_text(t)
print("patched: the scan job now stages tsguess.pdb from its own maximum")
PY

bash -n step19c_scan_product.sh && echo "syntax OK"
