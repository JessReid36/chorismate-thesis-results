#!/usr/bin/env python3
"""
compare_frames.py - compare two optimised reactant structures region by region.

The purpose is to ask where the difference between two frames' barriers comes
from.

ALIGNMENT IS REQUIRED, AND WHY
    Frames taken from a molecular dynamics trajectory are each in their own
    orientation, because the protein tumbles in the box as the simulation runs.
    Comparing two frames without alignment measures that tumbling and nothing
    else. Note that comparing centroids does NOT detect this: a rotation about
    the centroid leaves the centroid exactly where it was.

    The two structures are therefore superposed by the Kabsch algorithm on the
    frozen PROTEIN atoms, and solvent is excluded from every comparison.

SOLVENT MUST BE EXCLUDED, AND WHY
    Water diffuses. Two frames separated by 10.8 ns are separated by roughly
    sqrt(6Dt) = 120 A of bulk water displacement, so a given water molecule is
    the same molecule in both files but has wandered across the box. Including
    solvent gives a root-mean-square difference of about 58 A and a maximum of
    118 A, which is the box dimension and measures diffusion rather than
    conformation. Only the protein and the substrate are compared here.

Three regions are reported separately, and they mean different things.

  SUBSTRATE, the 24 quantum atoms
      How differently the reacting molecule itself sits. This is what the
      near-attack criterion describes.

  MOVABLE REGION, the 1959 atoms free to relax
      How differently the surrounding active site is arranged. These are the only
      atoms optimisation could move, so differences here are genuine differences
      between two local minima.

  FROZEN REGION, the remainder
      How different the two molecular dynamics snapshots were to begin with.
      These atoms never moved, so this is the baseline the optimisation inherited
      rather than anything it created.

The informative comparison is between the first two. A substrate that is nearly
identical while the active site differs substantially places the barrier
difference in the environment rather than in how the substrate is posed.

Usage:
  python3 compare_frames.py A.pdb B.pdb --inp <a reactant_opt.inp for the regions>
"""
import argparse, math, re, sys
import numpy as np


SOLVENT = {"WAT", "HOH", "TIP", "SOL", "NA", "CL", "NA+", "CL-", "K", "K+"}


def read_pdb(path):
    return [l for l in open(path, errors="replace")
            if l.startswith(("ATOM", "HETATM"))]


def is_solvent(l):
    return l[17:20].strip().upper() in SOLVENT


def xyz(l):
    return (float(l[30:38]), float(l[38:46]), float(l[46:54]))


def parse_regions(inp):
    """QMAtoms and ActiveAtoms from an ORCA QM/MM input. Both are zero-based."""
    txt = open(inp, errors="replace").read()
    def block(name):
        m = re.search(name + r"\s*\{([^}]*)\}", txt)
        if not m:
            return set()
        out = set()
        for tok in m.group(1).replace(",", " ").split():
            if ":" in tok:
                a, b = tok.split(":")
                out.update(range(int(a), int(b) + 1))
            else:
                out.add(int(tok))
        return out
    return block("QMAtoms"), block("ActiveAtoms")


def kabsch(P, Q):
    """Rotation and translation carrying P onto Q, by singular value
    decomposition of the covariance matrix. Standard rigid-body superposition."""
    cp, cq = P.mean(0), Q.mean(0)
    H = (P - cp).T @ (Q - cq)
    U, S, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    D = np.diag([1.0, 1.0, d])
    R = Vt.T @ D @ U.T
    return R, cp, cq


def rmsd(A, B, idx):
    if not idx:
        return float("nan"), float("nan"), None
    s = 0.0; worst = (0.0, None)
    for i in idx:
        d2 = sum((a - b) ** 2 for a, b in zip(xyz(A[i]), xyz(B[i])))
        s += d2
        if d2 > worst[0]:
            worst = (d2, i)
    return math.sqrt(s / len(idx)), math.sqrt(worst[0]), worst[1]


def label(l):
    return f"{l[17:20].strip()}{l[22:26].strip()} {l[12:16].strip()}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("a"); ap.add_argument("b")
    ap.add_argument("--inp", required=True,
                    help="any reactant_opt.inp; supplies the region definitions")
    ap.add_argument("--labels", nargs=2, default=None)
    args = ap.parse_args()

    A, B = read_pdb(args.a), read_pdb(args.b)
    if len(A) != len(B):
        sys.exit(f"atom counts differ: {len(A)} and {len(B)}")
    qm, act = parse_regions(args.inp)
    n = len(A)
    la, lb = args.labels or (args.a, args.b)

    print(f"{la}\n{lb}\n")
    print(f"{n} atoms each")

    solvent = {i for i, l in enumerate(A) if is_solvent(l)}
    print(f"  {len(solvent)} solvent atoms excluded, {n - len(solvent)} retained")
    frozen_idx = sorted(set(range(n)) - act - solvent)
    PA = np.array([xyz(l) for l in A])
    PB = np.array([xyz(l) for l in B])

    pre = float(np.sqrt(((PA[frozen_idx] - PB[frozen_idx]) ** 2).sum(1).mean()))
    R, cp, cq = kabsch(PA[frozen_idx], PB[frozen_idx])
    PA = (PA - cp) @ R.T + cq
    post = float(np.sqrt(((PA[frozen_idx] - PB[frozen_idx]) ** 2).sum(1).mean()))

    print(f"  frozen protein RMSD before alignment: {pre:8.3f} A")
    print(f"  frozen protein RMSD after alignment: {post:8.3f} A")
    print("  The frozen atoms were held fixed during optimisation, so after")
    print("  alignment they should agree closely. What remains is how much the two")
    print("  molecular dynamics snapshots genuinely differ, not how they were")
    print("  oriented in the box.")
    print()

    # rewrite the coordinate columns of A with the aligned positions
    A = [l[:30] + f"{PA[i][0]:8.3f}{PA[i][1]:8.3f}{PA[i][2]:8.3f}" + l[54:]
         for i, l in enumerate(A)]

    movable = sorted(act - qm - solvent)
    frozen = sorted(set(range(n)) - act - solvent)
    print(f"{'region':<28}{'atoms':>8}{'RMSD':>9}{'max':>9}   largest single displacement")
    print("-" * 86)
    for name, idx in (("substrate (QM)", sorted(qm)),
                      ("movable protein, excl. QM", movable),
                      ("frozen protein", frozen)):
        r, mx, wi = rmsd(A, B, idx)
        w = label(A[wi]) if wi is not None else ""
        print(f"{name:<28}{len(idx):>8}{r:>9.3f}{mx:>9.3f}   {w}")

    rq, _, _ = rmsd(A, B, sorted(qm))
    rm, _, _ = rmsd(A, B, movable)
    rf, _, _ = rmsd(A, B, frozen)
    print()
    print("Reading the result")
    print(f"  After alignment the frozen region differs by {rf:.3f} A. Those atoms")
    print("  never moved during optimisation, so this is how different the two")
    print("  snapshots genuinely were, and it is the baseline the other two numbers")
    print("  sit against.")
    if rq == rq and rm == rm and rq > 0:
        print(f"  The active site differs by {rm:.3f} A against {rq:.3f} A for the")
        print(f"  substrate, a ratio of {rm/rq:.1f}.")
        if rm / rq > 2:
            print("  The environment differs considerably more than the substrate does.")
            print("  Two frames can therefore place the substrate almost identically,")
            print("  and both satisfy the near-attack criterion, while the surrounding")
            print("  residues are arranged differently enough to change the barrier.")
        elif rm / rq < 0.5:
            print("  The substrate differs more than its surroundings, so the barrier")
            print("  difference is more plausibly a property of how the substrate is")
            print("  posed than of the environment around it.")
        else:
            print("  Substrate and environment differ comparably, so this pair does not")
            print("  separate the two explanations on its own.")
    print()
    print("  Note this is one pair of frames. It shows what differs between them,")
    print("  not what causes the barrier difference. The correlation across the full")
    print("  ensemble is the test of that.")


if __name__ == "__main__":
    main()
