#!/usr/bin/env bash
# patch_step19b.sh - three corrections to step19b_collect.py.
#
# 1. REPORT THE OPTIMISED GEOMETRY, NOT ONLY THE SELECTED ONE
#    The script joins each barrier to the step-12a selection manifest, whose
#    Arg90-O13 and forming C6-C1 distances are measured on the raw molecular
#    dynamics snapshot. The barrier, however, was computed from the OPTIMISED
#    reactant, and optimisation moves those distances: for frame 11630 the
#    manifest gives a forming distance of 3.152 A while the optimised reactant
#    gives 3.177 A. The two answer different questions. The manifest values ask
#    whether the sampled conformation predicts the barrier; the optimised values
#    ask whether the geometry the barrier was actually computed from predicts it,
#    which is the mechanistic question and the one the script's own header
#    describes. Both are now reported and both correlations are given.
#
#    The optimised values are read from 19_ensemble_harvest/reactant_summary.tsv,
#    written by step19d_harvest.py, which already holds them for every converged
#    frame.
#
# 2. DO NOT REPORT A DISTRIBUTION FROM TOO FEW FRAMES
#    At n = 2 the script printed a standard error of 1.43 and told the reader to
#    quote comparisons against it, and placed frame 820 at "+0.71 sd from the
#    ensemble mean". Neither is meaningful. Summary statistics are now withheld
#    below six frames, and correlations below eight, with the reason stated.
#
# 3. STATE WHICH GEOMETRY EACH CORRELATION USES
#    Reporting a single unlabelled correlation invites it being read as the
#    mechanistic one when it was computed from the selection manifest.
#
# Nothing about the barriers themselves changes. They are read from the
# climbing-image row of each converged NEB and are unaffected.

set -euo pipefail
[[ -f step19b_collect.py ]] || { echo "run from the directory holding step19b_collect.py"; exit 1; }
cp step19b_collect.py step19b_collect.py.bak2
echo "backup: step19b_collect.py.bak2"

python3 - <<'PY'
from pathlib import Path
p = Path("step19b_collect.py"); t = p.read_text()

# ---- reader for the harvested optimised geometries
anchor = "def stats(vals):"
reader = '''def read_harvest(path):
    """Optimised reactant geometry per frame, from step19d_harvest.py.

    These are the distances in the structure each barrier was actually computed
    from, as distinct from the manifest values, which describe the molecular
    dynamics snapshot the optimisation started from.
    """
    out = {}
    p = Path(path)
    if not p.exists():
        return out
    lines = [l.split("\\t") for l in p.read_text().splitlines() if l.strip()]
    hdr = [h.strip() for h in lines[0]]
    try:
        i_f = hdr.index("frame")
        i_b = hdr.index("break_O3_C4")
        i_m = hdr.index("form_C1_C6")
    except ValueError:
        return out
    for r in lines[1:]:
        try:
            out[int(r[i_f])] = {"opt_break": float(r[i_b]), "opt_form": float(r[i_m])}
        except (ValueError, IndexError):
            continue
    return out


'''
assert anchor in t
t = t.replace(anchor, reader + anchor, 1)

# ---- CLI option
old = '''    ap.add_argument("--out", default="ensemble_barriers.tsv")'''
new = '''    ap.add_argument("--harvest",
                    default=f"{home}/system_development/05_qmmm/19_ensemble_harvest/"
                            f"reactant_summary.tsv",
                    help="optimised reactant geometries, from step19d_harvest.py")
    ap.add_argument("--out", default="ensemble_barriers.tsv")'''
assert old in t
t = t.replace(old, new, 1)

old = "    man = read_manifest(args.manifest)"
new = "    man = read_manifest(args.manifest)\n    harv = read_harvest(args.harvest)"
assert old in t
t = t.replace(old, new, 1)

# ---- table: add the optimised columns
old = '''    print(f"{'frame':>7}{'ps':>9}{'barrier':>10}{'Arg90-O13':>12}"
          f"{'form C6-C1':>12}{'r':>9}")
    print("-" * 59)
    for fr, val, m in results:
        tag = "  <- fully characterised" if fr == REFERENCE_FRAME else ""
        print(f"{fr:>7}{m.get('ps', float('nan')):>9.0f}{val:>10.2f}"
              f"{m.get('arg90', float('nan')):>12.3f}"
              f"{m.get('form', float('nan')):>12.3f}"
              f"{m.get('r', float('nan')):>9.3f}{tag}")'''
new = '''    print("  as selected: distances measured on the molecular dynamics snapshot")
    print("  as optimised: distances in the reactant the barrier was computed from")
    print()
    print(f"{'frame':>7}{'barrier':>9}{'Arg90 sel':>11}{'form sel':>10}"
          f"{'break opt':>11}{'form opt':>10}")
    print("-" * 58)
    for fr, val, m in results:
        h = harv.get(fr, {})
        tag = "  <- fully characterised" if fr == REFERENCE_FRAME else ""
        print(f"{fr:>7}{val:>9.2f}"
              f"{m.get('arg90', float('nan')):>11.3f}"
              f"{m.get('form', float('nan')):>10.3f}"
              f"{h.get('opt_break', float('nan')):>11.3f}"
              f"{h.get('opt_form', float('nan')):>10.3f}{tag}")'''
assert old in t
t = t.replace(old, new, 1)

# ---- withhold statistics below six frames
old = '''    vals = [v for _, v, _ in results]
    if len(vals) < 2:
        print("\\nonly one barrier available - no distribution to report yet")
        sys.exit(0)

    mean, sd, sem = stats(vals)
    print(f"\\nENSEMBLE  (n = {len(vals)})")'''
new = '''    vals = [v for _, v, _ in results]
    MIN_FOR_STATS = 6
    if len(vals) < MIN_FOR_STATS:
        print(f"\\n{len(vals)} barrier(s) available. Summary statistics are withheld")
        print(f"below {MIN_FOR_STATS} frames: a mean, standard deviation and standard")
        print("error computed from a handful of frames invite being read as the")
        print("ensemble result, and the frames that finish first are not a random")
        print("sample of the ensemble.")
        if len(vals) >= 2:
            print(f"\\n  observed so far: {min(vals):.2f} to {max(vals):.2f} kcal/mol, "
                  f"spread {max(vals)-min(vals):.2f}")
        sys.exit(0)

    mean, sd, sem = stats(vals)
    print(f"\\nENSEMBLE  (n = {len(vals)})")'''
assert old in t
t = t.replace(old, new, 1)

# ---- correlations: label the geometry, require eight frames
old = '''    have = [(v, m) for _, v, m in results if m]
    if len(have) >= 3:
        b = [v for v, _ in have]
        print("\\n  CORRELATIONS across the ensemble")
        for key, label, expect in [
            ("arg90", "Arg90-O13 contact", "positive: looser contact, higher barrier"),
            ("form", "near-attack C6-C1", "positive: further from attack, higher barrier"),
        ]:
            x = [m[key] for _, m in have]
            r = pearson(x, b)
            print(f"    barrier vs {label:<20} r = {r:+.3f}   (expected {expect})")'''
new = '''    MIN_FOR_CORR = 8
    have = [(fr, v, m) for fr, v, m in results if m]
    if len(have) < MIN_FOR_CORR:
        print(f"\\n  Correlations are withheld below {MIN_FOR_CORR} frames.")
    else:
        b = [v for _, v, _ in have]
        print("\\n  CORRELATIONS across the ensemble")
        print("  Measured on the OPTIMISED reactant, the structure each barrier was")
        print("  computed from. This is the mechanistic question.")
        for key, label, expect in [
            ("opt_form", "forming C1-C6", "positive: further from attack, higher barrier"),
            ("opt_break", "breaking O3-C4", "no expectation; this bond is nearly invariant"),
        ]:
            pairs = [(harv[fr][key], v) for fr, v, _ in have
                     if fr in harv and key in harv[fr]]
            if len(pairs) >= MIN_FOR_CORR:
                r = pearson([a for a, _ in pairs], [c for _, c in pairs])
                print(f"    barrier vs {label:<18} r = {r:+.3f}  (n = {len(pairs)})"
                      f"   {expect}")
            else:
                print(f"    barrier vs {label:<18} only {len(pairs)} frames harvested")
        print("\\n  Measured AS SELECTED, on the molecular dynamics snapshot. This asks")
        print("  whether the sampled conformation predicts the barrier, which bears on")
        print("  whether the frame-selection criteria were informative.")
        for key, label, expect in [
            ("arg90", "Arg90-O13 contact", "positive: looser contact, higher barrier"),
            ("form", "near-attack C6-C1", "positive: further from attack, higher barrier"),
        ]:
            x = [m[key] for _, _, m in have]
            r = pearson(x, b)
            print(f"    barrier vs {label:<18} r = {r:+.3f}  (n = {len(x)})   {expect}")'''
assert old in t
t = t.replace(old, new, 1)
p.write_text(t)
print("patched: optimised geometry columns, thresholds, labelled correlations")
PY

python3 -c "import ast;ast.parse(open('step19b_collect.py').read())" && echo "syntax OK"
echo
echo "Now run it:  python3 step19b_collect.py"
