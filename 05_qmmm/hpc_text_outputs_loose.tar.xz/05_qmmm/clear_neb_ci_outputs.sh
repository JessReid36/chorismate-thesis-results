#!/usr/bin/env bash
# clear_neb_ci_outputs.sh - archive the NEB-CI outputs superseded by the
# protocol fix. Reports first, and deletes nothing without --apply.
#
# WHY THESE ARE SUPERSEDED
#   They were produced with NEB-CI and no transition-state guess, where the
#   reference path for frame 820 used NEB-TS with one. Their bands relax below
#   the converged reactant by up to 13.9 kcal/mol and their barriers span 4.48 to
#   24.65 kcal/mol, neither of which is comparable to the reference value of
#   15.94. They are not wrong calculations, they are calculations of a different
#   thing, and mixing them with the reruns would be worse than losing them.
#
# WHAT IS ARCHIVED, NOT DELETED
#   Everything is moved into 19_ensemble/frame_XXXXX/neb_ci_superseded/ rather
#   than removed, so the record survives for the methods chapter. The point that
#   a linear interpolation without a guess produces a band 2 to 2.5 times longer
#   than the reference is worth being able to show.
#
# WHAT IS NOT TOUCHED
#   reactant_opt, the scans, product_opt, and the staged reactant.pdb and
#   product.pdb. All of those are protocol-identical to the reference and are
#   reused by the rerun.
#
# Usage:
#   bash clear_neb_ci_outputs.sh            report only
#   bash clear_neb_ci_outputs.sh --apply    archive

set -uo pipefail
ENS="$HOME/system_development/05_qmmm/19_ensemble"
APPLY=0
[[ "${1:-}" == "--apply" ]] && APPLY=1

echo "Checking no NEB job is still running before anything is moved:"
live=$(qstat -f -u "$USER" 2>/dev/null | grep -c "cm19_n" || true)
echo "  NEB jobs in the queue: ${live:-0}"
if [[ "${live:-0}" != "0" ]]; then
  echo "  STOP: a NEB is still running. Let it finish or qdel it first."
  echo "  Moving files under a running job is how directories were corrupted earlier."
  exit 1
fi
echo

total=0
printf "%-8s %-10s %-12s %s\n" frame barrier "files (MB)" "to archive"
printf -- "--------------------------------------------------------------\n"
for d in "$ENS"/frame_*; do
  fr=$(basename "$d"); fr=${fr#frame_}
  [[ -f "$d/neb.out" ]] || continue
  b=$(awk '/PATH SUMMARY/,/Straight line/' "$d/neb.out" 2>/dev/null \
      | awk '$0 ~ /<= CI/ {print $4}' | head -1)
  n=$(ls "$d"/neb.* "$d"/neb_*.xyz 2>/dev/null | grep -v "neb.inp$" | grep -v "neb.pbs$" | wc -l)
  mb=$(du -cm "$d"/neb.out "$d"/neb*.xyz "$d"/neb*.tmp 2>/dev/null | tail -1 | cut -f1)
  total=$((total + ${mb:-0}))
  printf "%-8s %-10s %-12s %s\n" "$fr" "${b:-none}" "${mb:-0}" "$n files"
done
echo
echo "total: ${total} MB"
echo

if [[ $APPLY -eq 0 ]]; then
  echo "REPORT ONLY. Nothing has been moved."
  echo "Check the barriers above are the ones you expect to discard, then re-run"
  echo "with --apply. Files are archived under neb_ci_superseded/, not deleted."
  exit 0
fi

for d in "$ENS"/frame_*; do
  [[ -f "$d/neb.out" ]] || continue
  a="$d/neb_ci_superseded"
  mkdir -p "$a"
  for f in "$d"/neb.out "$d"/neb.pbs.out "$d"/neb*.xyz "$d"/neb*.tmp \
           "$d"/neb.densities "$d"/neb.gbw "$d"/neb.interp "$d"/neb.NEB.log; do
    [[ -e "$f" ]] && mv "$f" "$a/" 2>/dev/null
  done
  echo "  archived $(basename "$d") -> neb_ci_superseded/"
done
echo
echo "Done. The barriers are out of the way; step19b_collect.py will now report"
echo "no NEB output for these frames until the reruns finish."
